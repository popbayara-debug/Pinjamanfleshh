# 📊 Monitoring & Analytics Setup for PinjamanFlesh

## 🔍 Vercel Analytics (Built-in)

### Setup Vercel Analytics

1. **Go to Vercel Dashboard**
2. **Select your project**
3. **Click "Analytics" tab**
4. **Enable Speed Insights**
5. **Enable Web Vitals**
6. **Enable Analytics**

### What Vercel Tracks
- **Page Views**: Unique visitors and total views
- **Web Vitals**: LCP, FID, CLS metrics
- **Performance**: Core Web Vitals trends
- **Geographic Data**: Visitor locations
- **Device/Browser**: User technology
- **Referrers**: Traffic sources

### Vercel Analytics Dashboard
```
https://vercel.com/[your-username]/pinjamanflesh/analytics
```

## 🌐 Google Analytics 4

### Setup Google Analytics

1. **Go to [Google Analytics](https://analytics.google.com)**
2. **Create Account**: "PinjamanFlesh Business"
3. **Create Property**: "pinjamanflesh.com"
4. **Create Data Stream**: Web stream
5. **Get Measurement ID**: `G-XXXXXXXXXX`

### Install Google Analytics

#### Method 1: Next.js Script Component
```tsx
// src/components/analytics.tsx
'use client';

import Script from 'next/script';

export function Analytics() {
  return (
    <>
      <Script
        src="https://www.googletagmanager.com/gtag/js?id=G-XXXXXXXXXX"
        strategy="afterInteractive"
      />
      <Script id="google-analytics" strategy="afterInteractive">
        {`
          window.dataLayer = window.dataLayer || [];
          function gtag(){dataLayer.push(arguments);}
          gtag('js', new Date());
          gtag('config', 'G-XXXXXXXXXX');
        `}
      </Script>
    </>
  );
}
```

#### Method 2: Layout Integration
```tsx
// src/app/layout.tsx
import { Analytics } from '@/components/analytics';

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="id">
      <body>
        {children}
        <Analytics />
      </body>
    </html>
  );
}
```

### Google Analytics Events

#### Custom Event Tracking
```tsx
// Track WhatsApp clicks
const handleWhatsAppClick = () => {
  gtag('event', 'whatsapp_click', {
    event_category: 'engagement',
    event_label: 'whatsapp_button',
    value: 1,
  });
  
  // Open WhatsApp
  window.open('https://wa.me/6285892803452', '_blank');
};

// Track form submissions
const handleFormSubmit = () => {
  gtag('event', 'form_submission', {
    event_category: 'lead_generation',
    event_label: 'loan_application',
    value: loanAmount,
  });
};

// Track calculator usage
const handleCalculatorCalculation = () => {
  gtag('event', 'calculator_use', {
    event_category: 'tool_engagement',
    event_label: 'loan_calculator',
    value: loanAmount,
  });
};
```

#### E-commerce Events
```tsx
// Track loan product views
const trackProductView = (productName: string) => {
  gtag('event', 'view_item', {
    event_category: 'engagement',
    event_label: productName,
    currency: 'IDR',
    value: estimatedAmount,
  });
};

// Track loan recommendations
const trackRecommendation = (product: string, confidence: number) => {
  gtag('event', 'recommendation_generated', {
    event_category: 'ai_engagement',
    event_label: product,
    custom_parameter_1: confidence,
  });
};
```

## 🚨 Error Monitoring

### Vercel Error Logging
```bash
# View error logs
vercel logs

# Filter by errors
vercel logs --filter=error

# Real-time logs
vercel logs --follow
```

### Custom Error Tracking
```tsx
// src/lib/error-tracking.ts
export function trackError(error: Error, context?: string) {
  // Log to Vercel
  console.error(`[${context}]`, error);
  
  // Track in Google Analytics
  gtag('event', 'exception', {
    event_category: 'error',
    event_label: context || 'unknown',
    fatal: false,
    custom_parameter_1: error.message,
  });
}

// Usage example
try {
  await riskyOperation();
} catch (error) {
  trackError(error as Error, 'risky_operation');
}
```

## 📈 Performance Monitoring

### Core Web Vitals Tracking
```tsx
// src/components/performance-monitor.tsx
'use client';

import { useEffect } from 'react';

export function PerformanceMonitor() {
  useEffect(() => {
    // Track LCP (Largest Contentful Paint)
    new PerformanceObserver((list) => {
      const entries = list.getEntries();
      const lastEntry = entries[entries.length - 1];
      
      gtag('event', 'web_vitals', {
        event_category: 'performance',
        event_label: 'LCP',
        value: Math.round(lastEntry.startTime),
      });
    }).observe({ entryTypes: ['largest-contentful-paint'] });

    // Track FID (First Input Delay)
    new PerformanceObserver((list) => {
      const entries = list.getEntries();
      entries.forEach((entry) => {
        gtag('event', 'web_vitals', {
          event_category: 'performance',
          event_label: 'FID',
          value: Math.round(entry.processingStart - entry.startTime),
        });
      });
    }).observe({ entryTypes: ['first-input'] });

    // Track CLS (Cumulative Layout Shift)
    let clsValue = 0;
    new PerformanceObserver((list) => {
      const entries = list.getEntries();
      entries.forEach((entry) => {
        if (!(entry as any).hadRecentInput) {
          clsValue += (entry as any).value;
        }
      });
      
      gtag('event', 'web_vitals', {
        event_category: 'performance',
        event_label: 'CLS',
        value: Math.round(clsValue * 1000),
      });
    }).observe({ entryTypes: ['layout-shift'] });
  }, []);

  return null;
}
```

## 🔔 Uptime Monitoring

### Free Uptime Monitoring Services

#### Uptime Robot (Recommended)
1. **Sign up**: [uptimerobot.com](https://uptimerobot.com)
2. **Create Monitor**:
   - Monitor Type: HTTP(s)
   - URL: `https://pinjamanflesh.com`
   - Monitoring Interval: 5 minutes
   - Alert Contacts: Email/SMS

#### Pingdom
1. **Sign up**: [pingdom.com](https://pingdom.com)
2. **Setup Uptime Check**
3. **Configure Alerts**

### Custom Health Check Endpoint
```tsx
// src/app/api/health/route.ts
import { NextResponse } from 'next/server';

export async function GET() {
  try {
    // Check database connection
    // Check external services
    // Check system health
    
    return NextResponse.json({
      status: 'healthy',
      timestamp: new Date().toISOString(),
      uptime: process.uptime(),
      version: '1.0.0',
    });
  } catch (error) {
    return NextResponse.json(
      {
        status: 'unhealthy',
        error: error.message,
        timestamp: new Date().toISOString(),
      },
      { status: 500 }
    );
  }
}
```

## 📱 User Feedback Collection

### Feedback Widget
```tsx
// src/components/feedback-widget.tsx
'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { MessageCircle } from 'lucide-react';

export function FeedbackWidget() {
  const [isOpen, setIsOpen] = useState(false);
  const [feedback, setFeedback] = useState('');

  const submitFeedback = async () => {
    gtag('event', 'feedback_submitted', {
      event_category: 'engagement',
      event_label: 'feedback_widget',
    });

    // Send to your feedback endpoint
    await fetch('/api/feedback', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ feedback }),
    });

    setIsOpen(false);
    setFeedback('');
  };

  return (
    <div className="fixed bottom-4 right-4 z-50">
      {isOpen ? (
        <div className="bg-white p-4 rounded-lg shadow-lg w-80">
          <h3 className="font-semibold mb-2">Feedback</h3>
          <Textarea
            value={feedback}
            onChange={(e) => setFeedback(e.target.value)}
            placeholder="Bagaimana pengalaman Anda?"
            className="mb-2"
          />
          <div className="flex gap-2">
            <Button onClick={submitFeedback} size="sm">
              Kirim
            </Button>
            <Button onClick={() => setIsOpen(false)} variant="outline" size="sm">
              Batal
            </Button>
          </div>
        </div>
      ) : (
        <Button
          onClick={() => setIsOpen(true)}
          className="rounded-full w-12 h-12 p-0"
        >
          <MessageCircle className="w-5 h-5" />
        </Button>
      )}
    </div>
  );
}
```

## 📊 Business Metrics Dashboard

### Conversion Tracking
```tsx
// src/lib/conversion-tracking.ts
export const conversionEvents = {
  // Lead Generation
  loanApplicationStarted: 'loan_application_started',
  loanApplicationCompleted: 'loan_application_completed',
  whatsappContact: 'whatsapp_contact',
  
  // Engagement
  calculatorUsed: 'calculator_used',
  recommendationGenerated: 'recommendation_generated',
  comparisonToolUsed: 'comparison_tool_used',
  
  // User Journey
  pageView: 'page_view',
  timeOnSite: 'time_on_site',
  bounceRate: 'bounce_rate',
};

export function trackConversion(event: keyof typeof conversionEvents, value?: number) {
  gtag('event', conversionEvents[event], {
    event_category: 'conversion',
    event_label: event,
    value: value || 1,
  });
}
```

### Business KPIs to Track
- **Lead Conversion Rate**: Applications ÷ Visitors
- **WhatsApp Click Rate**: WhatsApp clicks ÷ Visitors
- **Calculator Usage**: Calculator uses ÷ Visitors
- **AI Recommendation Rate**: AI uses ÷ Visitors
- **Time on Page**: Average session duration
- **Bounce Rate**: Single-page sessions ÷ Total sessions

## 🔧 Monitoring Dashboard Setup

### Weekly Monitoring Routine
```bash
# Monday: Performance Review
- Check Lighthouse scores
- Review Core Web Vitals
- Analyze page load times

# Tuesday: User Behavior Analysis
- Review Google Analytics data
- Check conversion funnels
- Analyze user flow

# Wednesday: Error Monitoring
- Check error logs
- Review failed requests
- Monitor uptime

# Thursday: Content Performance
- Analyze popular pages
- Review exit pages
- Check search terms

# Friday: Weekly Summary
- Compile KPI report
- Identify improvement areas
- Plan next week optimizations
```

## 📈 Monthly Reporting

### KPI Report Template
```
PinjamanFlesh Monthly Performance Report
Month: [Month Year]

Traffic Metrics:
- Total Visitors: [number]
- Unique Visitors: [number]
- Page Views: [number]
- Avg. Session Duration: [time]

Conversion Metrics:
- Loan Applications: [number]
- WhatsApp Contacts: [number]
- Conversion Rate: [percentage]

Performance Metrics:
- Avg. Load Time: [seconds]
- Lighthouse Score: [score]
- Uptime: [percentage]

Top Pages:
1. [Page] - [views]
2. [Page] - [views]
3. [Page] - [views]

Key Insights:
- [Observation 1]
- [Observation 2]
- [Observation 3]

Action Items:
- [Action 1]
- [Action 2]
- [Action 3]
```

---

**📊 Proper monitoring will help you understand user behavior and optimize PinjamanFlesh for success!**