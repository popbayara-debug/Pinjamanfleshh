'use client';

import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Download, FileText, CheckCircle, ArrowLeft, MessageCircle, Phone, Mail } from 'lucide-react';
import Link from 'next/link';

export default function DownloadPage() {
  const [selectedProduct, setSelectedProduct] = useState('');
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    phone: '',
    company: '',
    purpose: ''
  });

  const products = [
    {
      id: 'pinjaman-kilat',
      name: 'Pinjaman Kilat',
      description: 'Pinjaman cepat dengan proses approval 24 jam',
      features: ['Proses 1x24 jam', 'Tanpa jaminan', 'Cair langsung'],
      color: 'from-orange-500 to-orange-600',
      documents: [
        { name: 'Form Pengajuan Pinjaman Kilat', type: 'PDF', size: '245 KB' },
        { name: 'Syarat & Ketentuan Pinjaman Kilat', type: 'PDF', size: '180 KB' },
        { name: 'Simulasi Pinjaman Kilat', type: 'Excel', size: '95 KB' }
      ]
    },
    {
      id: 'pinjaman-modal',
      name: 'Pinjaman Modal',
      description: 'Pinjaman untuk pengembangan bisnis Anda',
      features: ['Plafon tinggi', 'Bunga kompetitif', 'Jangka waktu fleksibel'],
      color: 'from-blue-500 to-blue-600',
      documents: [
        { name: 'Form Pengajuan Pinjaman Modal', type: 'PDF', size: '320 KB' },
        { name: 'Business Plan Template', type: 'Word', size: '150 KB' },
        { name: 'Syarat & Ketentuan Pinjaman Modal', type: 'PDF', size: '210 KB' }
      ]
    },
    {
      id: 'pinjaman-pendidikan',
      name: 'Pinjaman Pendidikan',
      description: 'Pinjaman khusus untuk kebutuhan pendidikan',
      features: ['Bunga khusus', 'Grace period', 'Untuk semua jenjang'],
      color: 'from-purple-500 to-purple-600',
      documents: [
        { name: 'Form Pengajuan Pinjaman Pendidikan', type: 'PDF', size: '280 KB' },
        { name: 'Panduan Beasiswa', type: 'PDF', size: '195 KB' },
        { name: 'Syarat & Ketentuan Pinjaman Pendidikan', type: 'PDF', size: '175 KB' }
      ]
    }
  ];

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleDownload = (docName: string) => {
    if (!selectedProduct || !formData.fullName || !formData.email) {
      alert('Silakan lengkapi data diri dan pilih produk terlebih dahulu');
      return;
    }
    
    // Simulasi download
    const link = document.createElement('a');
    link.href = `/documents/${selectedProduct}/${docName.replace(/ /g, '_').toLowerCase()}`;
    link.download = docName;
    link.click();
  };

  const handleWhatsAppDownload = () => {
    const message = `Halo, saya ingin mendapatkan informasi dan formulir download untuk ${selectedProduct}. Nama: ${formData.fullName}, Email: ${formData.email}, No. HP: ${formData.phone}`;
    const whatsappUrl = `https://wa.me/6285892803452?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
  };

  const selectedProductData = products.find(p => p.id === selectedProduct);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      {/* Header */}
      <header className="bg-white shadow-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 rounded-lg overflow-hidden shadow-md hover:shadow-lg transition-all duration-300 hover:scale-105 bg-white p-1">
                <img
                  src="/logo-clean.svg"
                  alt="PinjamanFlesh Logo"
                  className="w-full h-full object-contain"
                />
              </div>
              <h1 className="text-2xl font-bold bg-gradient-to-r from-emerald-600 to-teal-600 bg-clip-text text-transparent">
                PinjamanFlesh
              </h1>
            </div>
            <nav className="hidden md:flex space-x-6">
              <Link href="/" className="text-gray-600 hover:text-emerald-600 transition-colors">Beranda</Link>
              <Link href="/portfolio" className="text-gray-600 hover:text-emerald-600 transition-colors">Portfolio</Link>
              <Link href="/auth" className="text-gray-600 hover:text-emerald-600 transition-colors">Login</Link>
              <Button 
                onClick={() => window.location.href = '/'}
                className="bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700"
              >
                Ajukan Sekarang
              </Button>
            </nav>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Breadcrumb */}
        <nav className="flex mb-8">
          <Link href="/" className="text-gray-600 hover:text-emerald-600 transition-colors">
            <ArrowLeft className="w-4 h-4 inline mr-2" />
            Kembali ke Beranda
          </Link>
        </nav>

        <div className="grid md:grid-cols-2 gap-8">
          {/* Form Section */}
          <div>
            <Card className="mb-6">
              <CardHeader>
                <CardTitle className="text-xl">Data Pemohon</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="fullName">Nama Lengkap *</Label>
                  <Input
                    id="fullName"
                    name="fullName"
                    value={formData.fullName}
                    onChange={handleInputChange}
                    placeholder="Masukkan nama lengkap Anda"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="email">Email *</Label>
                  <Input
                    id="email"
                    name="email"
                    type="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    placeholder="email@example.com"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="phone">No. Telepon *</Label>
                  <Input
                    id="phone"
                    name="phone"
                    value={formData.phone}
                    onChange={handleInputChange}
                    placeholder="0812-3456-7890"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="company">Perusahaan/Institusi</Label>
                  <Input
                    id="company"
                    name="company"
                    value={formData.company}
                    onChange={handleInputChange}
                    placeholder="PT. Contoh Perusahaan"
                  />
                </div>
                <div>
                  <Label htmlFor="purpose">Tujuan Pinjaman</Label>
                  <Input
                    id="purpose"
                    name="purpose"
                    value={formData.purpose}
                    onChange={handleInputChange}
                    placeholder="Modal usaha, biaya pendidikan, dll."
                  />
                </div>
              </CardContent>
            </Card>

            {/* Product Selection */}
            <Card>
              <CardHeader>
                <CardTitle className="text-xl">Pilih Produk</CardTitle>
              </CardHeader>
              <CardContent>
                <Select value={selectedProduct} onValueChange={setSelectedProduct}>
                  <SelectTrigger>
                    <SelectValue placeholder="Pilih produk pinjaman" />
                  </SelectTrigger>
                  <SelectContent>
                    {products.map((product) => (
                      <SelectItem key={product.id} value={product.id}>
                        {product.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                {selectedProductData && (
                  <div className="mt-4 p-4 bg-gray-50 rounded-lg">
                    <h3 className="font-semibold mb-2">{selectedProductData.name}</h3>
                    <p className="text-gray-600 text-sm mb-3">{selectedProductData.description}</p>
                    <div className="flex flex-wrap gap-2">
                      {selectedProductData.features.map((feature, index) => (
                        <Badge key={index} variant="secondary" className="text-xs">
                          {feature}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Documents Section */}
          <div>
            <Card>
              <CardHeader>
                <CardTitle className="text-xl">Dokumen Download</CardTitle>
              </CardHeader>
              <CardContent>
                {selectedProductData ? (
                  <div className="space-y-4">
                    {selectedProductData.documents.map((doc, index) => (
                      <div key={index} className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50 transition-colors">
                        <div className="flex items-center space-x-3">
                          <div className={`w-10 h-10 rounded-lg bg-gradient-to-r ${selectedProductData.color} flex items-center justify-center`}>
                            <FileText className="w-5 h-5 text-white" />
                          </div>
                          <div>
                            <p className="font-medium">{doc.name}</p>
                            <p className="text-sm text-gray-500">{doc.type} • {doc.size}</p>
                          </div>
                        </div>
                        <Button
                          onClick={() => handleDownload(doc.name)}
                          size="sm"
                          className="bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700"
                        >
                          <Download className="w-4 h-4 mr-2" />
                          Download
                        </Button>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8 text-gray-500">
                    <FileText className="w-12 h-12 mx-auto mb-4 opacity-50" />
                    <p>Silakan pilih produk terlebih dahulu</p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Quick Actions */}
            {selectedProductData && (
              <Card className="mt-6">
                <CardHeader>
                  <CardTitle className="text-lg">Butuh Bantuan?</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Button
                    onClick={handleWhatsAppDownload}
                    className="w-full bg-green-500 hover:bg-green-600 flex items-center justify-center gap-2"
                  >
                    <MessageCircle className="w-4 h-4" />
                    Konsultasi via WhatsApp
                  </Button>
                  <div className="grid grid-cols-2 gap-3">
                    <Button variant="outline" className="flex items-center justify-center gap-2">
                      <Phone className="w-4 h-4" />
                      Call Center
                    </Button>
                    <Button variant="outline" className="flex items-center justify-center gap-2">
                      <Mail className="w-4 h-4" />
                      Email
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}