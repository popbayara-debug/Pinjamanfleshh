import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { fullName, email, phone, amount, purpose } = body;

    // Validasi input
    if (!fullName || !email || !phone || !amount || !purpose) {
      return NextResponse.json(
        { error: 'Semua field harus diisi' },
        { status: 400 }
      );
    }

    // Validasi email
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return NextResponse.json(
        { error: 'Format email tidak valid' },
        { status: 400 }
      );
    }

    // Validasi nomor telepon (minimal 10 digit)
    const phoneRegex = /^[0-9]{10,}$/;
    if (!phoneRegex.test(phone.replace(/[^0-9]/g, ''))) {
      return NextResponse.json(
        { error: 'Nomor telepon tidak valid (minimal 10 digit)' },
        { status: 400 }
      );
    }

    // Validasi jumlah pinjaman (minimal 1 juta)
    if (amount < 1000000) {
      return NextResponse.json(
        { error: 'Jumlah pinjaman minimal Rp 1.000.000' },
        { status: 400 }
      );
    }

    // Simpan ke database
    const application = await db.application.create({
      data: {
        fullName,
        email,
        phone,
        amount,
        purpose,
        status: 'pending'
      }
    });

    return NextResponse.json({
      success: true,
      message: 'Pengajuan pinjaman berhasil dikirim',
      applicationId: application.id
    });

  } catch (error) {
    console.error('Error creating application:', error);
    return NextResponse.json(
      { error: 'Terjadi kesalahan server' },
      { status: 500 }
    );
  }
}

export async function GET() {
  try {
    const applications = await db.application.findMany({
      orderBy: {
        createdAt: 'desc'
      }
    });

    return NextResponse.json({
      success: true,
      applications
    });

  } catch (error) {
    console.error('Error fetching applications:', error);
    return NextResponse.json(
      { error: 'Terjadi kesalahan server' },
      { status: 500 }
    );
  }
}