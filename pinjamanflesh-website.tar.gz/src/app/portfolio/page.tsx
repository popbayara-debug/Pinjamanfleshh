'use client';

import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ArrowLeft, TrendingUp, Users, DollarSign, Calendar, MapPin, CheckCircle, Star, MessageCircle, Download } from 'lucide-react';
import Link from 'next/link';

export default function PortfolioPage() {
  const [selectedCategory, setSelectedCategory] = useState('all');

  const caseStudies = [
    {
      id: 1,
      title: 'Toko Kelontong Maju Jaya',
      category: 'umkm',
      product: 'Pinjaman Modal',
      amount: 'Rp 50.000.000',
      location: 'Jakarta Selatan',
      date: '2024-01-15',
      description: 'Pengembangan usaha toko kelontong dengan penambahan stok dan renovasi toko.',
      results: [
        'Penjualan meningkat 150%',
        '10 karyawan baru',
        'Cabang baru dibuka'
      ],
      image: '/api/placeholder/400/250',
      rating: 5,
      testimonial: 'PinjamanFlesh sangat membantu usaha saya berkembang pesat. Proses cepat dan bunga terjangkau.'
    },
    {
      id: 2,
      title: 'Budi Santoso - Mahasiswa',
      category: 'pendidikan',
      product: 'Pinjaman Pendidikan',
      amount: 'Rp 15.000.000',
      location: 'Bandung',
      date: '2024-02-20',
      description: 'Biaya kuliah semester 7 di universitas swasta terkemuka.',
      results: [
        'Lancar biaya kuliah',
        'Tidak ada kendala pembayaran',
        'Fokus pada belajar'
      ],
      image: '/api/placeholder/400/250',
      rating: 5,
      testimonial: 'Terima kasih PinjamanFlesh, saya bisa melanjutkan kuliah tanpa khawatir biaya.'
    },
    {
      id: 3,
      title: 'CV. Sejahtera Bersama',
      category: 'bisnis',
      product: 'Pinjaman Modal',
      amount: 'Rp 200.000.000',
      location: 'Surabaya',
      date: '2024-01-10',
      description: 'Ekspansi bisnis kontraktor dengan pembelian alat berat baru.',
      results: [
        'Proyek meningkat 200%',
        '20 karyawan baru',
        'Omset naik 300%'
      ],
      image: '/api/placeholder/400/250',
      rating: 5,
      testimonial: 'Layanan profesional dan proses cepat. Sangat recommended untuk pengusaha.'
    },
    {
      id: 4,
      title: 'Siti Nurhaliza - Ibu Rumah Tangga',
      category: 'personal',
      product: 'Pinjaman Kilat',
      amount: 'Rp 5.000.000',
      location: 'Yogyakarta',
      date: '2024-03-05',
      description: 'Biaya medis darurat dan kebutuhan rumah tangga.',
      results: [
        'Cair dalam 24 jam',
        'Tidak ada tekanan',
        'Proses mudah'
      ],
      image: '/api/placeholder/400/250',
      rating: 5,
      testimonial: 'Sangat membantu saat keadaan darurat. Prosesnya mudah dan cepat.'
    },
    {
      id: 5,
      title: 'Workshop Digital Kreatif',
      category: 'umkm',
      product: 'Pinjaman Modal',
      amount: 'Rp 75.000.000',
      location: 'Bali',
      date: '2024-02-15',
      description: 'Pengadaan peralatan workshop dan modal bahan baku.',
      results: [
        'Produktivitas naik 120%',
        '8 karyawan baru',
        'Ekspor ke 3 negara'
      ],
      image: '/api/placeholder/400/250',
      rating: 5,
      testimonial: 'PinjamanFlesh memahami kebutuhan UMKM. Proses approval sangat cepat.'
    },
    {
      id: 6,
      title: 'Ahmad Fauzi - Karyawan Swasta',
      category: 'personal',
      product: 'Pinjaman Kilat',
      amount: 'Rp 10.000.000',
      location: 'Medan',
      date: '2024-03-10',
      description: 'Biaya pernikahan dan modal usaha kecil-kecilan.',
      results: [
        'Pernikahan lancar',
        'Usaha baru dimulai',
        'Pendapatan tambahan'
      ],
      image: '/api/placeholder/400/250',
      rating: 5,
      testimonial: 'Aplikasi pinjaman yang user friendly dan prosesnya transparan.'
    }
  ];

  const categories = [
    { id: 'all', name: 'Semua', color: 'bg-gray-500' },
    { id: 'umkm', name: 'UMKM', color: 'bg-green-500' },
    { id: 'bisnis', name: 'Bisnis', color: 'bg-blue-500' },
    { id: 'pendidikan', name: 'Pendidikan', color: 'bg-purple-500' },
    { id: 'personal', name: 'Personal', color: 'bg-orange-500' }
  ];

  const filteredCases = selectedCategory === 'all' 
    ? caseStudies 
    : caseStudies.filter(case_ => case_.category === selectedCategory);

  const getCategoryColor = (category: string) => {
    const cat = categories.find(c => c.id === category);
    return cat ? cat.color : 'bg-gray-500';
  };

  const getProductColor = (product: string) => {
    switch (product) {
      case 'Pinjaman Kilat': return 'from-orange-500 to-orange-600';
      case 'Pinjaman Modal': return 'from-blue-500 to-blue-600';
      case 'Pinjaman Pendidikan': return 'from-purple-500 to-purple-600';
      default: return 'from-gray-500 to-gray-600';
    }
  };

  const handleWhatsAppConsultation = (caseTitle: string) => {
    const message = `Halo, saya tertarik dengan case study "${caseTitle}" dan ingin konsultasi untuk pinjaman serupa.`;
    const whatsappUrl = `https://wa.me/6285892803452?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
  };

  const stats = {
    totalCases: caseStudies.length,
    totalAmount: 'Rp 355.000.000',
    satisfaction: '98%',
    avgRating: 4.9
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      {/* Header */}
      <header className="bg-white shadow-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 rounded-lg overflow-hidden shadow-md hover:shadow-lg transition-all duration-300 hover:scale-105 bg-white p-1">
                <img
                  src="/logo-clean.svg"
                  alt="PinjamanFlesh Logo"
                  className="w-full h-full object-contain"
                />
              </div>
              <h1 className="text-2xl font-bold bg-gradient-to-r from-emerald-600 to-teal-600 bg-clip-text text-transparent">
                PinjamanFlesh
              </h1>
            </div>
            <nav className="hidden md:flex space-x-6">
              <Link href="/" className="text-gray-600 hover:text-emerald-600 transition-colors">Beranda</Link>
              <Link href="/download" className="text-gray-600 hover:text-emerald-600 transition-colors">Download</Link>
              <Link href="/auth" className="text-gray-600 hover:text-emerald-600 transition-colors">Login</Link>
              <Button 
                onClick={() => window.location.href = '/'}
                className="bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700"
              >
                Ajukan Sekarang
              </Button>
            </nav>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Breadcrumb */}
        <nav className="flex mb-8">
          <Link href="/" className="text-gray-600 hover:text-emerald-600 transition-colors">
            <ArrowLeft className="w-4 h-4 inline mr-2" />
            Kembali ke Beranda
          </Link>
        </nav>

        {/* Hero Section */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Portfolio Sukses</h1>
          <p className="text-xl text-gray-600 mb-8">Cerita sukses nasabah PinjamanFlesh</p>
          
          {/* Stats */}
          <div className="grid md:grid-cols-4 gap-6 max-w-4xl mx-auto">
            <Card className="text-center p-6">
              <div className="w-12 h-12 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="w-6 h-6 text-emerald-600" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900">{stats.totalCases}</h3>
              <p className="text-gray-600">Case Studies</p>
            </Card>
            <Card className="text-center p-6">
              <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <DollarSign className="w-6 h-6 text-blue-600" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900">{stats.totalAmount}</h3>
              <p className="text-gray-600">Total Pinjaman</p>
            </Card>
            <Card className="text-center p-6">
              <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <TrendingUp className="w-6 h-6 text-green-600" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900">{stats.satisfaction}</h3>
              <p className="text-gray-600">Kepuasan</p>
            </Card>
            <Card className="text-center p-6">
              <div className="w-12 h-12 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Star className="w-6 h-6 text-yellow-600" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900">{stats.avgRating}</h3>
              <p className="text-gray-600">Rating Rata-rata</p>
            </Card>
          </div>
        </div>

        {/* Category Filter */}
        <div className="mb-8">
          <Tabs value={selectedCategory} onValueChange={setSelectedCategory}>
            <TabsList className="grid w-full grid-cols-5">
              {categories.map((category) => (
                <TabsTrigger key={category.id} value={category.id}>
                  {category.name}
                </TabsTrigger>
              ))}
            </TabsList>
          </Tabs>
        </div>

        {/* Case Studies Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredCases.map((case_) => (
            <Card key={case_.id} className="hover:shadow-xl transition-all duration-300 group">
              <CardHeader>
                <div className="flex items-center justify-between mb-4">
                  <Badge className={`${getCategoryColor(case_.category)} text-white`}>
                    {categories.find(c => c.id === case_.category)?.name}
                  </Badge>
                  <div className="flex items-center">
                    {[...Array(case_.rating)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 text-yellow-400 fill-current" />
                    ))}
                  </div>
                </div>
                <CardTitle className="text-xl mb-2">{case_.title}</CardTitle>
                <p className="text-gray-600 text-sm mb-4">{case_.description}</p>
              </CardHeader>
              <CardContent>
                {/* Image Placeholder */}
                <div className="w-full h-48 bg-gradient-to-br from-gray-100 to-gray-200 rounded-lg mb-4 flex items-center justify-center">
                  <div className="text-center">
                    <div className={`w-16 h-16 rounded-full bg-gradient-to-r ${getProductColor(case_.product)} flex items-center justify-center mx-auto mb-2`}>
                      <span className="text-white font-bold text-lg">
                        {case_.product.charAt(0)}
                      </span>
                    </div>
                    <p className="text-gray-500 text-sm">{case_.product}</p>
                  </div>
                </div>

                {/* Details */}
                <div className="space-y-3 mb-4">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Jumlah:</span>
                    <span className="font-semibold">{case_.amount}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Lokasi:</span>
                    <span className="font-semibold flex items-center">
                      <MapPin className="w-3 h-3 mr-1" />
                      {case_.location}
                    </span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Tanggal:</span>
                    <span className="font-semibold flex items-center">
                      <Calendar className="w-3 h-3 mr-1" />
                      {case_.date}
                    </span>
                  </div>
                </div>

                {/* Results */}
                <div className="mb-4">
                  <h4 className="font-semibold mb-2">Hasil:</h4>
                  <div className="space-y-1">
                    {case_.results.map((result, index) => (
                      <div key={index} className="flex items-center text-sm">
                        <CheckCircle className="w-3 h-3 text-green-500 mr-2" />
                        {result}
                      </div>
                    ))}
                  </div>
                </div>

                {/* Testimonial */}
                <div className="bg-gray-50 p-3 rounded-lg mb-4">
                  <p className="text-sm text-gray-700 italic">"{case_.testimonial}"</p>
                </div>

                {/* Actions */}
                <div className="flex space-x-2">
                  <Button
                    onClick={() => handleWhatsAppConsultation(case_.title)}
                    className="flex-1 bg-green-500 hover:bg-green-600 flex items-center justify-center gap-2"
                    size="sm"
                  >
                    <MessageCircle className="w-4 h-4" />
                    Konsultasi
                  </Button>
                  <Button
                    onClick={() => window.location.href = '/download'}
                    variant="outline"
                    className="flex items-center justify-center gap-2"
                    size="sm"
                  >
                    <Download className="w-4 h-4" />
                    Download
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}