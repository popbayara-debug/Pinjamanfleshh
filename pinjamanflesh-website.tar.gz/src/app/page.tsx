'use client';

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Calculator, Clock, Shield, TrendingUp, Users, CheckCircle, Star, Phone, Mail, MapPin, MessageCircle, Download, Menu, X, Sun, Moon, Search, ArrowRight, Sparkles } from 'lucide-react';
import { ThemeToggle } from '@/components/theme-toggle';
import { toast } from 'sonner';
import { AnimatedCounter } from '@/components/animated-counter';
import { ProgressBar } from '@/components/progress-bar';
import { ChatWidget } from '@/components/chat-widget';
import { AnalyticsDashboard } from '@/components/analytics-dashboard';
import { AIRecommendationEngine } from '@/components/ai-recommendation-engine';
import { ProductComparisonTool } from '@/components/product-comparison-tool';
import { AdvancedTestimonials } from '@/components/advanced-testimonials';
import { GamificationSystem } from '@/components/gamification-system';
import { AdvancedCalculator } from '@/components/advanced-calculator';

export default function Home() {
  const [loanAmount, setLoanAmount] = useState(10000000);
  const [loanTerm, setLoanTerm] = useState(12);
  const [monthlyPayment, setMonthlyPayment] = useState(0);
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    phone: '',
    amount: '',
    purpose: ''
  });
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [formErrors, setFormErrors] = useState({
    fullName: '',
    email: '',
    phone: '',
    amount: '',
    purpose: ''
  });

  const interestRate = 0.018; // 1.8% per month
  const whatsappNumber = '+6285892803452';

  useEffect(() => {
    const monthly = (loanAmount * (1 + interestRate * loanTerm)) / loanTerm;
    setMonthlyPayment(monthly);
  }, [loanAmount, loanTerm]);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleWhatsAppClick = (message?: string) => {
    const text = message || 'Halo, saya tertarik dengan layanan PinjamanFlesh. Mohon informasinya.';
    const whatsappUrl = `https://wa.me/${whatsappNumber.replace('+', '')}?text=${encodeURIComponent(text)}`;
    window.open(whatsappUrl, '_blank');
  };

  const getProductLogo = (productName: string) => {
    switch (productName) {
      case 'Pinjaman Kilat':
        return '/logo-pinjaman-kilat.svg';
      case 'Pinjaman Modal':
        return '/logo-pinjaman-modal.svg';
      case 'Pinjaman Pendidikan':
        return '/logo-pinjaman-pendidikan.svg';
      default:
        return '/logo-clean.svg';
    }
  };

  const getProductBadge = (productName: string) => {
    switch (productName) {
      case 'Pinjaman Kilat':
        return { text: 'Cair 24 Jam', color: 'bg-orange-100 text-orange-800' };
      case 'Pinjaman Modal':
        return { text: 'Bisnis', color: 'bg-blue-100 text-blue-800' };
      case 'Pinjaman Pendidikan':
        return { text: 'Edukasi', color: 'bg-purple-100 text-purple-800' };
      default:
        return { text: '', color: '' };
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const validateForm = () => {
    const errors = {
      fullName: '',
      email: '',
      phone: '',
      amount: '',
      purpose: ''
    };
    let isValid = true;

    // Name validation
    if (!formData.fullName.trim()) {
      errors.fullName = 'Nama lengkap harus diisi';
      isValid = false;
    } else if (formData.fullName.length < 3) {
      errors.fullName = 'Nama minimal 3 karakter';
      isValid = false;
    }

    // Email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!formData.email.trim()) {
      errors.email = 'Email harus diisi';
      isValid = false;
    } else if (!emailRegex.test(formData.email)) {
      errors.email = 'Format email tidak valid';
      isValid = false;
    }

    // Phone validation
    const phoneRegex = /^08[0-9]{9,12}$/;
    if (!formData.phone.trim()) {
      errors.phone = 'Nomor telepon harus diisi';
      isValid = false;
    } else if (!phoneRegex.test(formData.phone.replace(/[^0-9]/g, ''))) {
      errors.phone = 'Format nomor telepon tidak valid (contoh: 08xx-xxxx-xxxx)';
      isValid = false;
    }

    // Amount validation
    const amount = parseInt(formData.amount);
    if (!formData.amount.trim()) {
      errors.amount = 'Jumlah pinjaman harus diisi';
      isValid = false;
    } else if (isNaN(amount) || amount < 1000000) {
      errors.amount = 'Minimal pinjaman Rp 1.000.000';
      isValid = false;
    } else if (amount > 500000000) {
      errors.amount = 'Maksimal pinjaman Rp 500.000.000';
      isValid = false;
    }

    // Purpose validation
    if (!formData.purpose.trim()) {
      errors.purpose = 'Tujuan pinjaman harus diisi';
      isValid = false;
    } else if (formData.purpose.length < 10) {
      errors.purpose = 'Tujuan pinjaman minimal 10 karakter';
      isValid = false;
    }

    setFormErrors(errors);
    return isValid;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      toast.error('❌ Mohon perbaiki error pada form');
      return;
    }
    
    setIsLoading(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    try {
      const response = await fetch('/api/application', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          ...formData,
          amount: parseInt(formData.amount)
        }),
      });

      if (response.ok) {
        toast.success('✅ Pengajuan pinjaman berhasil dikirim! Tim kami akan segera menghubungi Anda.');
        setFormData({
          fullName: '',
          email: '',
          phone: '',
          amount: '',
          purpose: ''
        });
        setFormErrors({
          fullName: '',
          email: '',
          phone: '',
          amount: '',
          purpose: ''
        });
      } else {
        toast.error('❌ Terjadi kesalahan, silakan coba lagi.');
      }
    } catch (error) {
      toast.error('❌ Gagal mengirim pengajuan. Periksa koneksi Anda dan coba lagi.');
    } finally {
      setIsLoading(false);
    }
  };

  const loanProducts = [
    {
      name: 'Pinjaman Kilat',
      amount: '1Jt - 50Jt',
      term: '1-12 bulan',
      rate: '1.8%/bln',
      features: ['Proses cepat', 'Tanpa jaminan', 'Cair dalam 24 jam']
    },
    {
      name: 'Pinjaman Modal',
      amount: '10Jt - 500Jt',
      term: '6-36 bulan',
      rate: '1.5%/bln',
      features: ['Bunga kompetitif', 'Jangka waktu fleksibel', 'Untuk bisnis']
    },
    {
      name: 'Pinjaman Pendidikan',
      amount: '5Jt - 100Jt',
      term: '12-48 bulan',
      rate: '1.2%/bln',
      features: ['Bunga khusus', 'Grace period', 'Untuk pendidikan']
    }
  ];

  const testimonials = [
    {
      name: 'Budi Santoso',
      profession: 'Pengusaha',
      content: 'Proses pinjaman sangat cepat dan mudah. Dana cair dalam 1 hari untuk modal usaha saya.',
      rating: 5
    },
    {
      name: 'Siti Nurhaliza',
      profession: 'Ibu Rumah Tangga',
      content: 'Terima kasih PinjamanFlesh, membantu sekali saat keadaan darurat. Persyaratannya simple.',
      rating: 5
    },
    {
      name: 'Ahmad Fauzi',
      profession: 'Karyawan Swasta',
      content: 'Pelayanan sangat profesional dan transparan. Tidak ada biaya tersembunyi.',
      rating: 5
    }
  ];

  const faqs = [
    {
      question: 'Apa saja persyaratan untuk mengajukan pinjaman?',
      answer: 'Persyaratan utama: KTP, NPWP, slip gaji atau rekening koran 3 bulan terakhir, dan usia minimal 21 tahun.'
    },
    {
      question: 'Berapa lama proses approval pinjaman?',
      answer: 'Proses approval biasanya memakan waktu 1-2 hari kerja untuk pinjaman kilat, dan 3-5 hari kerja untuk pinjaman dengan jumlah lebih besar.'
    },
    {
      question: 'Apakah ada jaminan yang diperlukan?',
      answer: 'Untuk pinjaman di bawah 50 juta, tidak memerlukan jaminan. Untuk pinjaman di atas 50 juta, jaminan bisa berupa BPKB atau sertifikat tanah.'
    },
    {
      question: 'Bagaimana cara pembayaran angsuran?',
      answer: 'Pembayaran dapat dilakukan melalui transfer bank, virtual account, atau auto-debit dari rekening Anda.'
    }
  ];

  const filteredProducts = loanProducts.filter(product =>
    product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    product.features.some(feature => feature.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      {/* Header */}
      <motion.header 
        className={`bg-white/80 backdrop-blur-md shadow-sm sticky top-0 z-50 transition-all duration-300 ${
          isScrolled ? 'py-2 shadow-lg' : 'py-4'
        }`}
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center">
            <motion.div 
              className="flex items-center space-x-3"
              whileHover={{ scale: 1.05 }}
              transition={{ duration: 0.2 }}
            >
              <div className="w-10 h-10 rounded-lg overflow-hidden shadow-md hover:shadow-lg transition-all duration-300 hover:scale-105 bg-white p-1">
                <img
                  src="/logo-clean.svg"
                  alt="PinjamanFlesh Logo"
                  className="w-full h-full object-contain"
                />
              </div>
              <h1 className="text-2xl font-bold bg-gradient-to-r from-emerald-600 to-teal-600 bg-clip-text text-transparent hover:from-emerald-700 hover:to-teal-700 transition-all duration-300">
                PinjamanFlesh
              </h1>
            </motion.div>
            
            {/* Desktop Navigation */}
            <nav className="hidden md:flex space-x-6 items-center">
              {[
                { href: "#produk", label: "Produk" },
                { href: "#kalkulator", label: "Kalkulator" },
                { href: "/portfolio", label: "Portfolio" },
                { href: "/download", label: "Download" },
                { href: "/auth", label: "Login" }
              ].map((item, index) => (
                <motion.a
                  key={item.label}
                  href={item.href}
                  className="text-gray-600 hover:text-emerald-600 transition-colors relative group"
                  initial={{ opacity: 0, y: -20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3, delay: index * 0.1 }}
                  whileHover={{ scale: 1.1 }}
                >
                  {item.label}
                  <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-emerald-600 group-hover:w-full transition-all duration-300"></span>
                </motion.a>
              ))}
              <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.3, delay: 0.4 }}
              >
                <ThemeToggle />
              </motion.div>
              <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.3, delay: 0.5 }}
              >
                <motion.div
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <Button 
                    onClick={() => handleWhatsAppClick('Halo, saya tertarik dengan layanan PinjamanFlesh. Mohon informasinya.')}
                    className="bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 shadow-lg hover:shadow-xl transform hover:-translate-y-0.5 transition-all duration-300"
                  >
                    Ajukan Sekarang
                  </Button>
                </motion.div>
              </motion.div>
            </nav>

            {/* Mobile Menu Button */}
            <div className="md:hidden flex items-center space-x-2">
              <ThemeToggle />
              <motion.button
                className="p-2 rounded-lg hover:bg-gray-100 transition-colors"
                onClick={() => setIsMenuOpen(!isMenuOpen)}
                whileTap={{ scale: 0.95 }}
              >
                {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </motion.button>
            </div>
          </div>

          {/* Mobile Navigation */}
          <AnimatePresence>
            {isMenuOpen && (
              <motion.nav
                className="md:hidden mt-4 pb-4 border-t pt-4"
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                transition={{ duration: 0.3 }}
              >
                <div className="flex flex-col space-y-3">
                  {[
                    { href: "#produk", label: "Produk" },
                    { href: "#kalkulator", label: "Kalkulator" },
                    { href: "/portfolio", label: "Portfolio" },
                    { href: "/download", label: "Download" },
                    { href: "/auth", label: "Login" }
                  ].map((item) => (
                    <motion.a
                      key={item.label}
                      href={item.href}
                      className="text-gray-600 hover:text-emerald-600 transition-colors py-2"
                      whileHover={{ x: 10 }}
                      onClick={() => setIsMenuOpen(false)}
                    >
                      {item.label}
                    </motion.a>
                  ))}
                  <Button 
                    onClick={() => {
                      handleWhatsAppClick('Halo, saya tertarik dengan layanan PinjamanFlesh. Mohon informasinya.');
                      setIsMenuOpen(false);
                    }}
                    className="bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 w-full"
                  >
                    Ajukan Sekarang
                  </Button>
                </div>
              </motion.nav>
            )}
          </AnimatePresence>
        </div>
      </motion.header>

      {/* Hero Section */}
      <section className="py-20 px-4 overflow-hidden">
        <div className="container mx-auto">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <motion.div 
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
            >
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.2 }}
              >
                <Badge className="mb-4 bg-emerald-100 text-emerald-800 hover:bg-emerald-200">
                  <Sparkles className="w-4 h-4 mr-1" />
                  Terpercaya 10+ Tahun
                </Badge>
              </motion.div>
              <motion.h2 
                className="text-4xl md:text-5xl font-bold text-gray-900 mb-6"
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.4 }}
              >
                Pinjaman Cepat &{' '}
                <span className="bg-gradient-to-r from-emerald-600 to-teal-600 bg-clip-text text-transparent">
                  Terpercaya
                </span>
              </motion.h2>
              <motion.p 
                className="text-xl text-gray-600 mb-8"
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.6 }}
              >
                Solusi keuangan terbaik untuk kebutuhan pribadi dan bisnis Anda. 
                Proses mudah, bunga kompetitif, dan persetujuan cepat.
              </motion.p>
              <motion.div 
                className="flex flex-wrap gap-4 mb-8"
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.8 }}
              >
                {[
                  { icon: CheckCircle, text: 'Proses 24 Jam' },
                  { icon: CheckCircle, text: 'Bunga Rendah' },
                  { icon: CheckCircle, text: 'Tanpa Jaminan' }
                ].map((item, index) => (
                  <motion.div 
                    key={item.text}
                    className="flex items-center space-x-2"
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.5, delay: 1 + index * 0.1 }}
                    whileHover={{ scale: 1.05 }}
                  >
                    <item.icon className="w-5 h-5 text-emerald-600" />
                    <span className="text-gray-700">{item.text}</span>
                  </motion.div>
                ))}
              </motion.div>
              <motion.div 
                className="flex flex-wrap gap-4"
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 1.2 }}
              >
                <motion.div
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <Button 
                    size="lg" 
                    onClick={() => handleWhatsAppClick('Halo, saya ingin mengajukan pinjaman di PinjamanFlesh. Mohon bantuannya.')}
                    className="bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 flex items-center gap-2 shadow-lg hover:shadow-xl"
                  >
                    <MessageCircle className="w-5 h-5" />
                    Ajukan via WhatsApp
                    <ArrowRight className="w-4 h-4" />
                  </Button>
                </motion.div>
                <motion.div
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <Button 
                    size="lg" 
                    onClick={() => window.location.href = '/download'}
                    variant="outline"
                    className="flex items-center gap-2 border-2 hover:bg-emerald-50"
                  >
                    <Download className="w-5 h-5" />
                    Download Form
                  </Button>
                </motion.div>
                <motion.div
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <Button 
                    size="lg" 
                    onClick={() => window.location.href = '/portfolio'}
                    variant="outline"
                    className="flex items-center gap-2 border-2 hover:bg-emerald-50"
                  >
                    <Users className="w-5 h-5" />
                    Lihat Portfolio
                  </Button>
                </motion.div>
              </motion.div>
            </motion.div>
            <motion.div 
              className="relative"
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.3 }}
            >
              <motion.div 
                className="absolute inset-0 bg-gradient-to-r from-emerald-400 to-teal-500 rounded-3xl transform rotate-3"
                animate={{ rotate: [3, 5, 3] }}
                transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
              ></motion.div>
              <motion.div
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ duration: 0.6, delay: 0.6 }}
              >
                <Card className="relative bg-white p-8 rounded-3xl shadow-xl">
                  <h3 className="text-2xl font-bold mb-6 text-center">Ajukan Pinjaman</h3>
                  <form onSubmit={handleSubmit} className="space-y-4">
                    <motion.div
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.5, delay: 0.8 }}
                    >
                      <Label htmlFor="fullName">Nama Lengkap</Label>
                      <Input
                        id="fullName"
                        name="fullName"
                        value={formData.fullName}
                        onChange={handleInputChange}
                        required
                        className={`mt-1 focus:ring-2 focus:ring-emerald-500 ${
                          formErrors.fullName ? 'border-red-500' : ''
                        }`}
                        placeholder="Masukkan nama lengkap"
                      />
                      {formErrors.fullName && (
                        <motion.p
                          initial={{ opacity: 0, y: -10 }}
                          animate={{ opacity: 1, y: 0 }}
                          className="text-red-500 text-sm mt-1"
                        >
                          {formErrors.fullName}
                        </motion.p>
                      )}
                    </motion.div>
                    <motion.div
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.5, delay: 0.9 }}
                    >
                      <Label htmlFor="email">Email</Label>
                      <Input
                        id="email"
                        name="email"
                        type="email"
                        value={formData.email}
                        onChange={handleInputChange}
                        required
                        className={`mt-1 focus:ring-2 focus:ring-emerald-500 ${
                          formErrors.email ? 'border-red-500' : ''
                        }`}
                        placeholder="email@example.com"
                      />
                      {formErrors.email && (
                        <motion.p
                          initial={{ opacity: 0, y: -10 }}
                          animate={{ opacity: 1, y: 0 }}
                          className="text-red-500 text-sm mt-1"
                        >
                          {formErrors.email}
                        </motion.p>
                      )}
                    </motion.div>
                    <motion.div
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.5, delay: 1.0 }}
                    >
                      <Label htmlFor="phone">No. Telepon</Label>
                      <Input
                        id="phone"
                        name="phone"
                        value={formData.phone}
                        onChange={handleInputChange}
                        required
                        className={`mt-1 focus:ring-2 focus:ring-emerald-500 ${
                          formErrors.phone ? 'border-red-500' : ''
                        }`}
                        placeholder="08xx-xxxx-xxxx"
                      />
                      {formErrors.phone && (
                        <motion.p
                          initial={{ opacity: 0, y: -10 }}
                          animate={{ opacity: 1, y: 0 }}
                          className="text-red-500 text-sm mt-1"
                        >
                          {formErrors.phone}
                        </motion.p>
                      )}
                    </motion.div>
                    <motion.div
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.5, delay: 1.1 }}
                    >
                      <Label htmlFor="amount">Jumlah Pinjaman (Rp)</Label>
                      <Input
                        id="amount"
                        name="amount"
                        type="number"
                        value={formData.amount}
                        onChange={handleInputChange}
                        required
                        className={`mt-1 focus:ring-2 focus:ring-emerald-500 ${
                          formErrors.amount ? 'border-red-500' : ''
                        }`}
                        placeholder="10000000"
                      />
                      {formErrors.amount && (
                        <motion.p
                          initial={{ opacity: 0, y: -10 }}
                          animate={{ opacity: 1, y: 0 }}
                          className="text-red-500 text-sm mt-1"
                        >
                          {formErrors.amount}
                        </motion.p>
                      )}
                    </motion.div>
                    <motion.div
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.5, delay: 1.2 }}
                    >
                      <Label htmlFor="purpose">Tujuan Pinjaman</Label>
                      <Textarea
                        id="purpose"
                        name="purpose"
                        value={formData.purpose}
                        onChange={handleInputChange}
                        required
                        className={`mt-1 focus:ring-2 focus:ring-emerald-500 ${
                          formErrors.purpose ? 'border-red-500' : ''
                        }`}
                        placeholder="Jelaskan tujuan pinjaman Anda..."
                        rows={3}
                      />
                      {formErrors.purpose && (
                        <motion.p
                          initial={{ opacity: 0, y: -10 }}
                          animate={{ opacity: 1, y: 0 }}
                          className="text-red-500 text-sm mt-1"
                        >
                          {formErrors.purpose}
                        </motion.p>
                      )}
                    </motion.div>
                    <motion.div
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.5, delay: 1.3 }}
                    >
                      <motion.div
                        whileHover={{ scale: isLoading ? 1 : 1.02 }}
                        whileTap={{ scale: isLoading ? 1 : 0.98 }}
                      >
                        <Button 
                          type="submit" 
                          className="w-full bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 shadow-lg hover:shadow-xl transform hover:-translate-y-0.5 transition-all duration-300"
                          disabled={isLoading}
                        >
                          {isLoading ? (
                            <motion.div
                              animate={{ rotate: 360 }}
                              transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                              className="flex items-center justify-center"
                            >
                              <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full"></div>
                            </motion.div>
                          ) : (
                            'Ajukan Sekarang'
                          )}
                        </Button>
                      </motion.div>
                    </motion.div>
                  </form>
                </Card>
              </motion.div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-16 px-4 bg-white">
        <div className="container mx-auto">
          <motion.div 
            className="text-center mb-12"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Mengapa Memilih PinjamanFlesh?</h2>
            <p className="text-xl text-gray-600">Keunggulan yang membuat kami berbeda</p>
          </motion.div>
          <div className="grid md:grid-cols-4 gap-8">
            {[
              {
                icon: Clock,
                title: 'Proses Cepat',
                description: 'Persetujuan dalam 24 jam untuk pinjaman kilat',
                color: 'emerald'
              },
              {
                icon: Shield,
                title: 'Aman & Terpercaya',
                description: 'Terdaftar dan diawasi OJK',
                color: 'blue'
              },
              {
                icon: TrendingUp,
                title: 'Bunga Kompetitif',
                description: 'Suku bunga mulai dari 1.2% per bulan',
                color: 'purple'
              },
              {
                icon: Users,
                title: 'Layanan Pelanggan',
                description: 'Support 24/7 untuk membantu Anda',
                color: 'orange'
              }
            ].map((feature, index) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <Card className="text-center p-6 hover:shadow-xl transition-all duration-300 group cursor-pointer">
                  <motion.div 
                    className={`w-12 h-12 bg-${feature.color}-100 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-300`}
                    whileHover={{ rotate: 360 }}
                    transition={{ duration: 0.6 }}
                  >
                    <feature.icon className={`w-6 h-6 text-${feature.color}-600`} />
                  </motion.div>
                  <h3 className="font-semibold mb-2 group-hover:text-emerald-600 transition-colors">
                    {feature.title}
                  </h3>
                  <p className="text-gray-600 text-sm">{feature.description}</p>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Statistics */}
      <section className="py-16 px-4 bg-gradient-to-r from-emerald-50 to-teal-50">
        <div className="container mx-auto">
          <motion.div 
            className="text-center mb-12"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-3xl font-bold text-gray-900 mb-4">PinjamanFlesh dalam Angka</h2>
            <p className="text-xl text-gray-600">Pencapaian kami dalam membantu nasabah</p>
          </motion.div>
          
          <div className="grid md:grid-cols-4 gap-8 mb-12">
            {[
              { 
                end: 10000, 
                label: 'Nasabah Puas', 
                icon: Users,
                color: 'text-emerald-600',
                bgColor: 'bg-emerald-100'
              },
              { 
                end: 500, 
                label: 'Pinjaman Disetujui', 
                icon: CheckCircle,
                color: 'text-blue-600',
                bgColor: 'bg-blue-100'
              },
              { 
                end: 98, 
                label: 'Tingkat Kepuasan (%)', 
                icon: Star,
                color: 'text-yellow-600',
                bgColor: 'bg-yellow-100'
              },
              { 
                end: 24, 
                label: 'Jam Proses Cepat', 
                icon: Clock,
                color: 'text-purple-600',
                bgColor: 'bg-purple-100'
              }
            ].map((stat, index) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <Card className="text-center p-6 hover:shadow-lg transition-all duration-300">
                  <motion.div 
                    className={`w-12 h-12 ${stat.bgColor} rounded-full flex items-center justify-center mx-auto mb-4`}
                    whileHover={{ scale: 1.1, rotate: 360 }}
                    transition={{ duration: 0.6 }}
                  >
                    <stat.icon className={`w-6 h-6 ${stat.color}`} />
                  </motion.div>
                  <div className="text-3xl font-bold text-gray-900 mb-2">
                    <AnimatedCounter end={stat.end} />
                    {stat.label.includes('%') && '%'}
                  </div>
                  <p className="text-gray-600">{stat.label}</p>
                </Card>
              </motion.div>
            ))}
          </div>

          {/* Progress Indicators */}
          <motion.div 
            className="grid md:grid-cols-2 gap-8"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.4 }}
          >
            <Card className="p-6">
              <h3 className="text-xl font-semibold mb-6">Kinerja Kami</h3>
              <div className="space-y-4">
                <ProgressBar value={95} max={100} label="Approval Rate" color="bg-emerald-500" />
                <ProgressBar value={88} max={100} label="Customer Satisfaction" color="bg-blue-500" />
                <ProgressBar value={92} max={100} label="Process Efficiency" color="bg-purple-500" />
                <ProgressBar value={78} max={100} label="Market Coverage" color="bg-orange-500" />
              </div>
            </Card>
            
            <Card className="p-6">
              <h3 className="text-xl font-semibold mb-6">Distribusi Produk</h3>
              <div className="space-y-4">
                <ProgressBar value={45} max={100} label="Pinjaman Kilat" color="bg-orange-500" />
                <ProgressBar value={35} max={100} label="Pinjaman Modal" color="bg-blue-500" />
                <ProgressBar value={20} max={100} label="Pinjaman Pendidikan" color="bg-purple-500" />
              </div>
            </Card>
          </motion.div>
        </div>
      </section>

      {/* Analytics Dashboard */}
      <section className="py-16 px-4 bg-white">
        <div className="container mx-auto">
          <motion.div 
            className="text-center mb-12"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Analytics Dashboard</h2>
            <p className="text-xl text-gray-600">Real-time insights into our performance</p>
          </motion.div>
          
          <AnalyticsDashboard />
        </div>
      </section>

      {/* AI Recommendation Engine */}
      <section className="py-16 px-4 bg-gradient-to-br from-purple-50 to-pink-50">
        <div className="container mx-auto">
          <motion.div 
            className="text-center mb-12"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-3xl font-bold text-gray-900 mb-4">AI-Powered Recommendations</h2>
            <p className="text-xl text-gray-600">Get personalized loan suggestions powered by artificial intelligence</p>
          </motion.div>
          
          <AIRecommendationEngine />
        </div>
      </section>

      {/* Product Comparison Tool */}
      <section className="py-16 px-4 bg-white">
        <div className="container mx-auto">
          <motion.div 
            className="text-center mb-12"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Advanced Product Comparison</h2>
            <p className="text-xl text-gray-600">Compare our loan products side-by-side to make the best choice</p>
          </motion.div>
          
          <ProductComparisonTool />
        </div>
      </section>

      {/* Products */}
      <section id="produk" className="py-16 px-4">
        <div className="container mx-auto">
          <motion.div 
            className="text-center mb-12"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Produk Pinjaman</h2>
            <p className="text-xl text-gray-600 mb-8">Pilih produk yang sesuai kebutuhan Anda</p>
            
            {/* Search Bar */}
            <motion.div 
              className="max-w-md mx-auto mb-8"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <Input
                  type="text"
                  placeholder="Cari produk pinjaman..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
                />
              </div>
            </motion.div>
          </motion.div>
          
          <div className="grid md:grid-cols-3 gap-8">
            {filteredProducts.map((product, index) => (
              <motion.div
                key={product.name}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <Card className="hover:shadow-xl transition-all duration-300 group cursor-pointer">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <motion.div 
                          className="w-8 h-8 rounded-lg overflow-hidden shadow-sm hover:shadow-md transition-all duration-300 hover:scale-105"
                          whileHover={{ rotate: 360 }}
                          transition={{ duration: 0.6 }}
                        >
                          <img
                            src={getProductLogo(product.name)}
                            alt={`${product.name} Logo`}
                            className="w-full h-full object-contain"
                          />
                        </motion.div>
                        <CardTitle className="text-xl">{product.name}</CardTitle>
                      </div>
                      <Badge className={`text-xs ${getProductBadge(product.name).color}`}>
                        {getProductBadge(product.name).text}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3 mb-6">
                      <div className="flex justify-between">
                        <span className="text-gray-600">Jumlah:</span>
                        <span className="font-semibold">Rp {product.amount}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Jangka Waktu:</span>
                        <span className="font-semibold">{product.term}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Bunga:</span>
                        <span className="font-semibold text-emerald-600">{product.rate}</span>
                      </div>
                    </div>
                    <div className="space-y-2 mb-6">
                      {product.features.map((feature, idx) => (
                        <div key={idx} className="flex items-center space-x-2">
                          <CheckCircle className="w-4 h-4 text-emerald-600" />
                          <span className="text-sm text-gray-700">{feature}</span>
                        </div>
                      ))}
                    </div>
                    <div className="space-y-2">
                      <motion.div
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                      >
                        <Button 
                          className="w-full bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 flex items-center justify-center gap-2"
                          onClick={() => handleWhatsAppClick(`Halo, saya tertarik dengan produk ${product.name}. Mohon informasinya.`)}
                        >
                          <MessageCircle className="w-4 h-4" />
                          Ajukan via WhatsApp
                        </Button>
                      </motion.div>
                      <motion.div
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                      >
                        <Button 
                          variant="outline" 
                          className="w-full flex items-center justify-center gap-2"
                          onClick={() => window.location.href = '/download'}
                        >
                          <Download className="w-4 h-4" />
                          Download Form
                        </Button>
                      </motion.div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
          
          {filteredProducts.length === 0 && (
            <motion.div 
              className="text-center py-12"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
            >
              <p className="text-gray-500 text-lg">Tidak ada produk yang ditemukan untuk "{searchQuery}"</p>
              <Button 
                variant="outline" 
                className="mt-4"
                onClick={() => setSearchQuery('')}
              >
                Reset Pencarian
              </Button>
            </motion.div>
          )}
        </div>
      </section>

      {/* Calculator */}
      <section id="kalkulator" className="py-16 px-4 bg-white">
        <div className="container mx-auto">
          <motion.div 
            className="text-center mb-12"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Advanced Calculator with Amortization</h2>
            <p className="text-xl text-gray-600">Calculate loans with detailed amortization schedule</p>
          </motion.div>
          <div className="max-w-2xl mx-auto">
            <Card className="p-8">
              <div className="space-y-6">
                <div>
                  <Label htmlFor="amount">Jumlah Pinjaman (Rp)</Label>
                  <Input
                    id="amount"
                    type="number"
                    value={loanAmount}
                    onChange={(e) => setLoanAmount(parseInt(e.target.value) || 0)}
                    className="mt-1"
                  />
                </div>
                <div>
                  <Label htmlFor="term">Jangka Waktu (bulan)</Label>
                  <Select value={loanTerm.toString()} onValueChange={(value) => setLoanTerm(parseInt(value))}>
                    <SelectTrigger className="mt-1">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="6">6 bulan</SelectItem>
                      <SelectItem value="12">12 bulan</SelectItem>
                      <SelectItem value="24">24 bulan</SelectItem>
                      <SelectItem value="36">36 bulan</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="bg-emerald-50 p-6 rounded-lg">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-gray-600">Total Pinjaman</p>
                      <p className="text-2xl font-bold text-gray-900">Rp {loanAmount.toLocaleString('id-ID')}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Bunga ({(interestRate * 100).toFixed(1)}%/bln)</p>
                      <p className="text-2xl font-bold text-emerald-600">Rp {(loanAmount * interestRate * loanTerm).toLocaleString('id-ID')}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Cicilan per Bulan</p>
                      <p className="text-2xl font-bold text-emerald-600">Rp {Math.round(monthlyPayment).toLocaleString('id-ID')}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Total Pembayaran</p>
                      <p className="text-2xl font-bold text-gray-900">Rp {Math.round(monthlyPayment * loanTerm).toLocaleString('id-ID')}</p>
                    </div>
                  </div>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </section>

      {/* Advanced Testimonials */}
      <section id="testimoni" className="py-16 px-4 bg-gradient-to-br from-blue-50 to-purple-50">
        <div className="container mx-auto">
          <motion.div 
            className="text-center mb-12"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Customer Stories & Video Reviews</h2>
            <p className="text-xl text-gray-600">Real experiences from our valued customers</p>
          </motion.div>
          
          <AdvancedTestimonials />
        </div>
      </section>

      {/* Gamification System */}
      <section className="py-16 px-4 bg-gradient-to-br from-yellow-50 to-orange-50">
        <div className="container mx-auto">
          <motion.div 
            className="text-center mb-12"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Gamification & Rewards</h2>
            <p className="text-xl text-gray-600">Earn points, unlock achievements, and claim exclusive rewards</p>
          </motion.div>
          
          <GamificationSystem />
        </div>
      </section>

      {/* FAQ */}
      <section id="faq" className="py-16 px-4 bg-white">
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Frequently Asked Questions</h2>
            <p className="text-xl text-gray-600">Pertanyaan yang sering diajukan</p>
          </div>
          <div className="max-w-3xl mx-auto">
            <Tabs defaultValue="0" className="w-full">
              <TabsList className="grid w-full grid-cols-4">
                {faqs.map((faq, index) => (
                  <TabsTrigger key={index} value={index.toString()}>
                    Q{index + 1}
                  </TabsTrigger>
                ))}
              </TabsList>
              {faqs.map((faq, index) => (
                <TabsContent key={index} value={index.toString()} className="mt-4">
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg">{faq.question}</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-gray-700">{faq.answer}</p>
                    </CardContent>
                  </Card>
                </TabsContent>
              ))}
            </Tabs>
          </div>
        </div>
      </section>

      {/* Contact */}
      <section className="py-16 px-4 bg-gradient-to-r from-emerald-600 to-teal-600">
        <div className="container mx-auto text-center text-white">
          <h2 className="text-3xl font-bold mb-4">Butuh Bantuan?</h2>
          <p className="text-xl mb-8">Tim kami siap membantu Anda 24/7</p>
          <div className="grid md:grid-cols-3 gap-8 max-w-3xl mx-auto">
            <div className="flex flex-col items-center">
              <MessageCircle className="w-8 h-8 mb-2" />
              <p className="font-semibold">WhatsApp</p>
              <p>{whatsappNumber}</p>
              <Button 
                onClick={() => handleWhatsAppClick()}
                className="mt-2 bg-white text-green-600 hover:bg-gray-100 border border-green-600"
                size="sm"
              >
                Chat Sekarang
              </Button>
            </div>
            <div className="flex flex-col items-center">
              <Mail className="w-8 h-8 mb-2" />
              <p className="font-semibold">Email</p>
              <p>info@pinjamanflesh.com</p>
            </div>
            <div className="flex flex-col items-center">
              <MapPin className="w-8 h-8 mb-2" />
              <p className="font-semibold">Alamat</p>
              <p>Jakarta, Indonesia</p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-8 px-4">
        <div className="container mx-auto">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-10 h-10 rounded-lg overflow-hidden shadow-md hover:shadow-lg transition-all duration-300 hover:scale-105 bg-white p-1">
                  <img
                    src="/logo-financial.svg"
                    alt="PinjamanFlesh Logo"
                    className="w-full h-full object-contain"
                  />
                </div>
                <h3 className="text-xl font-bold">PinjamanFlesh</h3>
              </div>
              <p className="text-gray-400">Solusi pinjaman terpercaya untuk kebutuhan finansial Anda.</p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Produk</h4>
              <ul className="space-y-2 text-gray-400">
                <li>Advanced Calculator</li>
                <li>Amortization Schedule</li>
                <li>Loan Comparison</li>
                <li>Financial Analysis</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Layanan</h4>
              <ul className="space-y-2 text-gray-400">
                <li>Kalkulator Pinjaman</li>
                <li>Simulasi Kredit</li>
                <li>Konsultasi</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Legal</h4>
              <ul className="space-y-2 text-gray-400">
                <li>Syarat & Ketentuan</li>
                <li>Kebijakan Privasi</li>
                <li>Terdaftar OJK</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2024 PinjamanFlesh. All rights reserved.</p>
          </div>
        </div>
      </footer>

      {/* WhatsApp Floating Button */}
      <motion.div
        className="fixed bottom-6 right-6 z-50"
        initial={{ opacity: 0, scale: 0 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5, delay: 2 }}
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
      >
        <motion.div
          animate={{ y: [0, -10, 0] }}
          transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
        >
          <Button
            onClick={() => handleWhatsAppClick('Halo, saya tertarik dengan layanan PinjamanFlesh. Mohon informasinya.')}
            className="bg-green-500 hover:bg-green-600 text-white rounded-full w-14 h-14 shadow-lg hover:shadow-xl transition-all duration-300 group"
            size="icon"
          >
            <MessageCircle className="w-6 h-6 group-hover:scale-110 transition-transform" />
          </Button>
        </motion.div>
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.3, delay: 2.5 }}
          className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center animate-pulse"
        >
          1
        </motion.div>
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          whileHover={{ opacity: 1, y: 0 }}
          className="absolute bottom-16 right-0 bg-white rounded-lg shadow-lg p-3 opacity-0 group-hover:opacity-100 transition-all duration-300 pointer-events-none"
        >
          <p className="text-sm text-gray-700 whitespace-nowrap">Butuh bantuan? Chat kami!</p>
        </motion.div>
      </motion.div>
      
      <ChatWidget />
    </div>
  );
}