import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { ThemeProvider } from "@/components/theme-provider";
import { Toaster as Sonner } from "sonner";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  metadataBase: new URL("https://pinjamanflesh.com"),
  title: "PinjamanFlesh - Pinjaman Online Cepat & Terpercaya",
  description: "Solusi pinjaman online terpercaya untuk kebutuhan pribadi dan bisnis Anda. Proses mudah, bunga kompetitif, dan persetujuan cepat.",
  keywords: ["PinjamanFlesh", "pinjaman online", "pinjaman cepat", "fintech", "pinjaman terpercaya", "pinjaman tanpa jaminan"],
  authors: [{ name: "PinjamanFlesh Team" }],
  icons: {
    icon: "/favicon.png",
    shortcut: "/favicon.png",
    apple: "/favicon.png",
  },
  openGraph: {
    title: "PinjamanFlesh - Pinjaman Online Cepat & Terpercaya",
    description: "Solusi pinjaman online terpercaya untuk kebutuhan pribadi dan bisnis Anda. Proses mudah, bunga kompetitif, dan persetujuan cepat.",
    url: "https://pinjamanflesh.com",
    siteName: "PinjamanFlesh",
    type: "website",
    images: [
      {
        url: "/logo-clean.svg",
        width: 1024,
        height: 1024,
        alt: "PinjamanFlesh Logo",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "PinjamanFlesh - Pinjaman Online Cepat & Terpercaya",
    description: "Solusi pinjaman online terpercaya untuk kebutuhan pribadi dan bisnis Anda. Proses mudah, bunga kompetitif, dan persetujuan cepat.",
    images: ["/logo-clean.svg"],
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="id" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        <ThemeProvider
          attribute="class"
          defaultTheme="system"
          enableSystem
          disableTransitionOnChange
        >
          {children}
          <Toaster />
          <Sonner position="top-right" />
        </ThemeProvider>
      </body>
    </html>
  );
}
