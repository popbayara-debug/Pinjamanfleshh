'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { 
  Trophy, 
  Star, 
  Target, 
  Zap, 
  Gift, 
  Crown, 
  Medal, 
  Flame,
  Rocket,
  Award,
  Lock,
  Unlock
} from 'lucide-react';

interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: React.ReactNode;
  points: number;
  unlocked: boolean;
  category: 'application' | 'payment' | 'engagement' | 'milestone';
  progress?: number;
  maxProgress?: number;
}

interface Reward {
  id: string;
  title: string;
  description: string;
  points: number;
  type: 'discount' | 'cashback' | 'voucher' | 'exclusive';
  claimed: boolean;
  icon: React.ReactNode;
}

interface UserStats {
  level: number;
  points: number;
  applications: number;
  onTimePayments: number;
  referrals: number;
  streak: number;
  nextLevelPoints: number;
  badges: string[];
}

export function GamificationSystem() {
  const [userStats, setUserStats] = useState<UserStats>({
    level: 5,
    points: 2450,
    applications: 3,
    onTimePayments: 12,
    referrals: 2,
    streak: 7,
    nextLevelPoints: 3000,
    badges: ['Fast Approver', 'Reliable Payer']
  });

  const [selectedCategory, setSelectedCategory] = useState<'all' | 'application' | 'payment' | 'engagement' | 'milestone'>('all');

  const achievements: Achievement[] = [
    {
      id: 'first_app',
      title: 'Pemula',
      description: 'Mengajukan pinjaman pertama',
      icon: <Rocket className="w-6 h-6 text-blue-500" />,
      points: 50,
      unlocked: true,
      category: 'application'
    },
    {
      id: 'fast_approval',
      title: 'Cepat & Tepat',
      description: 'Pinjaman disetujui dalam 24 jam',
      icon: <Zap className="w-6 h-6 text-yellow-500" />,
      points: 100,
      unlocked: true,
      category: 'application'
    },
    {
      id: 'perfect_payment',
      title: 'Pembayar Handal',
      description: '10 pembayaran tepat waktu',
      icon: <Star className="w-6 h-6 text-green-500" />,
      points: 200,
      unlocked: true,
      category: 'payment'
    },
    {
      id: 'payment_streak',
      title: 'Beruntun',
      description: 'Streak 5 pembayaran berturut-turut',
      icon: <Flame className="w-6 h-6 text-orange-500" />,
      points: 150,
      unlocked: true,
      category: 'payment'
    },
    {
      id: 'referral_master',
      title: 'Juru Rekomendasi',
      description: 'Mereferensikan 5 teman',
      icon: <Target className="w-6 h-6 text-purple-500" />,
      points: 300,
      unlocked: true,
      category: 'engagement'
    },
    {
      id: 'level_10',
      title: 'Master Pinjaman',
      description: 'Mencapai level 10',
      icon: <Crown className="w-6 h-6 text-yellow-600" />,
      points: 500,
      unlocked: false,
      category: 'milestone'
    },
    {
      id: 'millionaire',
      title: 'Jutawan',
      description: 'Total pinjaman Rp 1 Miliar',
      icon: <Trophy className="w-6 h-6 text-yellow-500" />,
      points: 1000,
      unlocked: false,
      category: 'milestone'
    },
    {
      id: 'early_bird',
      title: 'Pagi Burung',
      description: '5 pengajuan sebelum jam 9 pagi',
      icon: <Medal className="w-6 h-6 text-blue-600" />,
      points: 250,
      unlocked: false,
      progress: 3,
      maxProgress: 5,
      category: 'engagement'
    }
  ];

  const rewards: Reward[] = [
    {
      id: 'discount_5',
      title: 'Diskon 5%',
      description: 'Diskon 5% untuk pinjaman berikutnya',
      points: 500,
      type: 'discount',
      claimed: false,
      icon: <Gift className="w-6 h-6 text-green-500" />
    },
    {
      id: 'cashback_100k',
      title: 'Cashback Rp 100K',
      description: 'Cashback Rp 100.000 untuk pembayaran tepat waktu',
      points: 750,
      type: 'cashback',
      claimed: false,
      icon: <Award className="w-6 h-6 text-blue-500" />
    },
    {
      id: 'voucher_200k',
      title: 'Voucher Rp 200K',
      description: 'Voucher Rp 200.000 untuk ulang tahun',
      points: 1000,
      type: 'voucher',
      claimed: true,
      icon: <Gift className="w-6 h-6 text-purple-500" />
    },
    {
      id: 'exclusive_rate',
      title: 'Bunga Eksklusif',
      description: 'Bunga khusus 0.5% lebih rendah',
      points: 1500,
      type: 'exclusive',
      claimed: false,
      icon: <Crown className="w-6 h-6 text-yellow-600" />
    }
  ];

  const filteredAchievements = achievements.filter(achievement => 
    selectedCategory === 'all' || achievement.category === selectedCategory
  );

  const getLevelColor = (level: number) => {
    if (level >= 10) return 'text-yellow-600';
    if (level >= 7) return 'text-purple-600';
    if (level >= 5) return 'text-blue-600';
    if (level >= 3) return 'text-green-600';
    return 'text-gray-600';
  };

  const getLevelTitle = (level: number) => {
    if (level >= 10) return 'Master';
    if (level >= 7) return 'Expert';
    if (level >= 5) return 'Advanced';
    if (level >= 3) return 'Intermediate';
    return 'Beginner';
  };

  const claimReward = (rewardId: string) => {
    // In real app, this would call API
    console.log('Claiming reward:', rewardId);
  };

  return (
    <div className="space-y-6">
      {/* User Stats Dashboard */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <Card className="bg-gradient-to-r from-purple-50 to-pink-50">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Trophy className="w-6 h-6 mr-2 text-yellow-600" />
              Your Gamification Dashboard
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-6">
              {/* Level */}
              <motion.div
                className="text-center"
                whileHover={{ scale: 1.05 }}
              >
                <div className={`w-16 h-16 mx-auto mb-2 rounded-full bg-gradient-to-r from-purple-500 to-pink-500 flex items-center justify-center`}>
                  <Crown className="w-8 h-8 text-white" />
                </div>
                <div className={`text-2xl font-bold ${getLevelColor(userStats.level)}`}>
                  Level {userStats.level}
                </div>
                <div className="text-sm text-gray-600">{getLevelTitle(userStats.level)}</div>
              </motion.div>

              {/* Points */}
              <motion.div
                className="text-center"
                whileHover={{ scale: 1.05 }}
              >
                <div className="w-16 h-16 mx-auto mb-2 rounded-full bg-gradient-to-r from-yellow-400 to-orange-500 flex items-center justify-center">
                  <Star className="w-8 h-8 text-white" />
                </div>
                <div className="text-2xl font-bold text-yellow-600">
                  {userStats.points.toLocaleString()}
                </div>
                <div className="text-sm text-gray-600">Points</div>
              </motion.div>

              {/* Applications */}
              <motion.div
                className="text-center"
                whileHover={{ scale: 1.05 }}
              >
                <div className="w-16 h-16 mx-auto mb-2 rounded-full bg-gradient-to-r from-blue-400 to-blue-600 flex items-center justify-center">
                  <Target className="w-8 h-8 text-white" />
                </div>
                <div className="text-2xl font-bold text-blue-600">{userStats.applications}</div>
                <div className="text-sm text-gray-600">Applications</div>
              </motion.div>

              {/* On-time Payments */}
              <motion.div
                className="text-center"
                whileHover={{ scale: 1.05 }}
              >
                <div className="w-16 h-16 mx-auto mb-2 rounded-full bg-gradient-to-r from-green-400 to-green-600 flex items-center justify-center">
                  <Zap className="w-8 h-8 text-white" />
                </div>
                <div className="text-2xl font-bold text-green-600">{userStats.onTimePayments}</div>
                <div className="text-sm text-gray-600">On-time Payments</div>
              </motion.div>

              {/* Referrals */}
              <motion.div
                className="text-center"
                whileHover={{ scale: 1.05 }}
              >
                <div className="w-16 h-16 mx-auto mb-2 rounded-full bg-gradient-to-r from-purple-400 to-purple-600 flex items-center justify-center">
                  <Rocket className="w-8 h-8 text-white" />
                </div>
                <div className="text-2xl font-bold text-purple-600">{userStats.referrals}</div>
                <div className="text-sm text-gray-600">Referrals</div>
              </motion.div>

              {/* Streak */}
              <motion.div
                className="text-center"
                whileHover={{ scale: 1.05 }}
              >
                <div className="w-16 h-16 mx-auto mb-2 rounded-full bg-gradient-to-r from-orange-400 to-red-500 flex items-center justify-center">
                  <Flame className="w-8 h-8 text-white" />
                </div>
                <div className="text-2xl font-bold text-orange-600">{userStats.streak}</div>
                <div className="text-sm text-gray-600">Day Streak</div>
              </motion.div>

              {/* Progress to Next Level */}
              <motion.div
                className="text-center"
                whileHover={{ scale: 1.05 }}
              >
                <div className="w-16 h-16 mx-auto mb-2 rounded-full bg-gradient-to-r from-gray-400 to-gray-600 flex items-center justify-center">
                  {userStats.points >= userStats.nextLevelPoints ? (
                    <Unlock className="w-8 h-8 text-white" />
                  ) : (
                    <Lock className="w-8 h-8 text-white" />
                  )}
                </div>
                <div className="text-2xl font-bold text-gray-600">
                  {userStats.nextLevelPoints - userStats.points}
                </div>
                <div className="text-sm text-gray-600">To Next Level</div>
              </motion.div>
            </div>

            {/* Level Progress */}
            <div className="mt-6">
              <div className="flex justify-between mb-2">
                <span className="text-sm font-medium">Progress to Level {userStats.level + 1}</span>
                <span className="text-sm text-gray-600">
                  {userStats.points} / {userStats.nextLevelPoints} points
                </span>
              </div>
              <Progress 
                value={(userStats.points / userStats.nextLevelPoints) * 100} 
                className="h-3"
              />
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Achievements */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.1 }}
      >
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <div className="flex items-center">
                <Medal className="w-6 h-6 mr-2 text-yellow-600" />
                Achievements
              </div>
              <div className="flex space-x-2">
                {[
                  { key: 'all', label: 'Semua' },
                  { key: 'application', label: 'Pengajuan' },
                  { key: 'payment', label: 'Pembayaran' },
                  { key: 'engagement', label: 'Engagement' },
                  { key: 'milestone', label: 'Milestone' }
                ].map(category => (
                  <Button
                    key={category.key}
                    variant={selectedCategory === category.key ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setSelectedCategory(category.key as any)}
                  >
                    {category.label}
                  </Button>
                ))}
              </div>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredAchievements.map((achievement, index) => (
                <motion.div
                  key={achievement.id}
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.3, delay: index * 0.1 }}
                  whileHover={{ scale: 1.05 }}
                >
                  <Card className={`h-full ${achievement.unlocked ? 'bg-white border-2 border-yellow-400' : 'bg-gray-50 opacity-75'}`}>
                    <CardContent className="p-4 text-center">
                      <div className={`w-12 h-12 mx-auto mb-3 rounded-full flex items-center justify-center ${
                        achievement.unlocked ? 'bg-yellow-100' : 'bg-gray-200'
                      }`}>
                        {achievement.icon}
                      </div>
                      <h3 className={`font-semibold mb-2 ${achievement.unlocked ? 'text-gray-900' : 'text-gray-500'}`}>
                        {achievement.title}
                      </h3>
                      <p className={`text-sm mb-3 ${achievement.unlocked ? 'text-gray-600' : 'text-gray-400'}`}>
                        {achievement.description}
                      </p>
                      <div className="flex items-center justify-between">
                        <Badge className={achievement.unlocked ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-600'}>
                          {achievement.unlocked ? 'Unlocked' : 'Locked'}
                        </Badge>
                        <div className="flex items-center">
                          <Star className="w-4 h-4 text-yellow-500 mr-1" />
                          <span className="font-semibold">{achievement.points}</span>
                        </div>
                      </div>
                      {achievement.progress !== undefined && (
                        <div className="mt-3">
                          <div className="flex justify-between mb-1">
                            <span className="text-xs text-gray-600">Progress</span>
                            <span className="text-xs text-gray-600">
                              {achievement.progress} / {achievement.maxProgress}
                            </span>
                          </div>
                          <Progress 
                            value={(achievement.progress! / achievement.maxProgress!) * 100} 
                            className="h-2"
                          />
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Rewards Store */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.2 }}
      >
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Gift className="w-6 h-6 mr-2 text-green-600" />
              Rewards Store
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="mb-4 p-4 bg-blue-50 rounded-lg">
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <Star className="w-5 h-5 text-yellow-500 mr-2" />
                  <span className="font-semibold">Your Points:</span>
                </div>
                <span className="text-2xl font-bold text-yellow-600">{userStats.points.toLocaleString()}</span>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {rewards.map((reward, index) => (
                <motion.div
                  key={reward.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3, delay: index * 0.1 }}
                  whileHover={{ scale: 1.02 }}
                >
                  <Card className={`h-full ${reward.claimed ? 'opacity-75' : ''}`}>
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between mb-3">
                        <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${
                          reward.type === 'discount' ? 'bg-green-100' :
                          reward.type === 'cashback' ? 'bg-blue-100' :
                          reward.type === 'voucher' ? 'bg-purple-100' : 'bg-yellow-100'
                        }`}>
                          {reward.icon}
                        </div>
                        <Badge className={
                          reward.type === 'discount' ? 'bg-green-100 text-green-800' :
                          reward.type === 'cashback' ? 'bg-blue-100 text-blue-800' :
                          reward.type === 'voucher' ? 'bg-purple-100 text-purple-800' : 'bg-yellow-100 text-yellow-800'
                        }>
                          {reward.type === 'discount' ? 'Diskon' :
                           reward.type === 'cashback' ? 'Cashback' :
                           reward.type === 'voucher' ? 'Voucher' : 'Eksklusif'}
                        </Badge>
                      </div>
                      <h3 className={`font-semibold mb-2 ${reward.claimed ? 'text-gray-500' : 'text-gray-900'}`}>
                        {reward.title}
                      </h3>
                      <p className={`text-sm mb-3 ${reward.claimed ? 'text-gray-400' : 'text-gray-600'}`}>
                        {reward.description}
                      </p>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center">
                          <Star className="w-4 h-4 text-yellow-500 mr-1" />
                          <span className="font-semibold">{reward.points}</span>
                        </div>
                        <motion.div
                          whileHover={{ scale: 1.05 }}
                          whileTap={{ scale: 0.95 }}
                        >
                          <Button
                            size="sm"
                            disabled={reward.claimed || userStats.points < reward.points}
                            onClick={() => claimReward(reward.id)}
                            className={reward.claimed ? 'opacity-50' : ''}
                          >
                            {reward.claimed ? 'Claimed' : 
                             userStats.points < reward.points ? 'Insufficient Points' : 'Claim'}
                          </Button>
                        </motion.div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}