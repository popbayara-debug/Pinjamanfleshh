'use client';

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { 
  Brain, 
  TrendingUp, 
  DollarSign, 
  Clock, 
  Shield, 
  CheckCircle,
  AlertCircle,
  Lightbulb
} from 'lucide-react';

interface UserProfile {
  age: number;
  income: number;
  employmentType: string;
  creditScore: number;
  existingLoans: number;
  purpose: string;
  urgency: string;
  preferredTerm: number;
}

interface LoanRecommendation {
  product: string;
  confidence: number;
  reasons: string[];
  estimatedAmount: number;
  estimatedRate: number;
  processingTime: string;
  pros: string[];
  cons: string[];
  matchScore: number;
}

export function AIRecommendationEngine() {
  const [userProfile, setUserProfile] = useState<UserProfile>({
    age: 30,
    income: 10000000,
    employmentType: '',
    creditScore: 750,
    existingLoans: 0,
    purpose: '',
    urgency: '',
    preferredTerm: 12
  });

  const [recommendations, setRecommendations] = useState<LoanRecommendation[]>([]);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [showResults, setShowResults] = useState(false);

  const analyzeProfile = async () => {
    setIsAnalyzing(true);
    
    // Simulate AI processing
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    const recommendations: LoanRecommendation[] = [];
    
    // AI Logic for recommendations
    if (userProfile.income >= 5000000 && userProfile.creditScore >= 700) {
      recommendations.push({
        product: 'Pinjaman Kilat',
        confidence: 92,
        reasons: [
          'High credit score qualifies for fast approval',
          'Income level meets minimum requirements',
          'No existing loans detected'
        ],
        estimatedAmount: Math.min(userProfile.income * 5, 50000000),
        estimatedRate: 1.8,
        processingTime: '24 jam',
        pros: ['Fastest approval', 'Minimal documentation', 'Same-day disbursement'],
        cons: ['Lower maximum amount', 'Higher interest rate'],
        matchScore: 95
      });
    }
    
    if (userProfile.income >= 8000000 && userProfile.creditScore >= 650) {
      recommendations.push({
        product: 'Pinjaman Modal',
        confidence: 88,
        reasons: [
          'Stable income supports business loan',
          'Good credit history',
          'Suitable for business expansion'
        ],
        estimatedAmount: Math.min(userProfile.income * 10, 500000000),
        estimatedRate: 1.5,
        processingTime: '3-5 hari',
        pros: ['Higher loan amount', 'Lower interest rate', 'Flexible terms'],
        cons: ['Longer processing time', 'More documentation required'],
        matchScore: 88
      });
    }
    
    if (userProfile.purpose.toLowerCase().includes('pendidikan') || 
        userProfile.purpose.toLowerCase().includes('education') ||
        userProfile.purpose.toLowerCase().includes('kuliah')) {
      recommendations.push({
        product: 'Pinjaman Pendidikan',
        confidence: 85,
        reasons: [
          'Education purpose detected',
          'Specialized rates for education',
          'Grace period available'
        ],
        estimatedAmount: Math.min(userProfile.income * 8, 100000000),
        estimatedRate: 1.2,
        processingTime: '2-3 hari',
        pros: ['Lowest interest rate', 'Grace period', 'Education-focused'],
        cons: ['Specific purpose only', 'Moderate amount'],
        matchScore: 82
      });
    }
    
    // Sort by match score
    recommendations.sort((a, b) => b.matchScore - a.matchScore);
    
    setRecommendations(recommendations);
    setIsAnalyzing(false);
    setShowResults(true);
  };

  const getConfidenceColor = (confidence: number) => {
    if (confidence >= 90) return 'bg-green-100 text-green-800';
    if (confidence >= 80) return 'bg-yellow-100 text-yellow-800';
    return 'bg-red-100 text-red-800';
  };

  const getMatchScoreColor = (score: number) => {
    if (score >= 90) return 'text-green-600';
    if (score >= 80) return 'text-yellow-600';
    return 'text-red-600';
  };

  return (
    <div className="space-y-6">
      {/* Input Form */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Brain className="w-6 h-6 mr-2 text-purple-600" />
              AI Loan Recommendation Engine
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="age">Usia</Label>
                <Input
                  id="age"
                  type="number"
                  value={userProfile.age}
                  onChange={(e) => setUserProfile({...userProfile, age: parseInt(e.target.value)})}
                  placeholder="21-65"
                />
              </div>
              <div>
                <Label htmlFor="income">Penghasilan Bulanan (Rp)</Label>
                <Input
                  id="income"
                  type="number"
                  value={userProfile.income}
                  onChange={(e) => setUserProfile({...userProfile, income: parseInt(e.target.value)})}
                  placeholder="5000000"
                />
              </div>
              <div>
                <Label htmlFor="employment">Tipe Pekerjaan</Label>
                <Select onValueChange={(value) => setUserProfile({...userProfile, employmentType: value})}>
                  <SelectTrigger>
                    <SelectValue placeholder="Pilih tipe pekerjaan" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="permanent">Pegawai Tetap</SelectItem>
                    <SelectItem value="contract">Pegawai Kontrak</SelectItem>
                    <SelectItem value="freelance">Freelance</SelectItem>
                    <SelectItem value="business">Pemilik Bisnis</SelectItem>
                    <SelectItem value="professional">Profesional</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="credit">Skor Kredit (300-850)</Label>
                <Input
                  id="credit"
                  type="number"
                  value={userProfile.creditScore}
                  onChange={(e) => setUserProfile({...userProfile, creditScore: parseInt(e.target.value)})}
                  placeholder="750"
                />
              </div>
              <div>
                <Label htmlFor="loans">Pinjaman Aktif</Label>
                <Input
                  id="loans"
                  type="number"
                  value={userProfile.existingLoans}
                  onChange={(e) => setUserProfile({...userProfile, existingLoans: parseInt(e.target.value)})}
                  placeholder="0"
                />
              </div>
              <div>
                <Label htmlFor="urgency">Tingkat Kepentingan</Label>
                <Select onValueChange={(value) => setUserProfile({...userProfile, urgency: value})}>
                  <SelectTrigger>
                    <SelectValue placeholder="Seberapa penting?" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="immediate">Sangat Mendesak</SelectItem>
                    <SelectItem value="urgent">Mendesak</SelectItem>
                    <SelectItem value="normal">Normal</SelectItem>
                    <SelectItem value="flexible">Fleksibel</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="term">Jangka Waktu Diinginkan (bulan)</Label>
                <Input
                  id="term"
                  type="number"
                  value={userProfile.preferredTerm}
                  onChange={(e) => setUserProfile({...userProfile, preferredTerm: parseInt(e.target.value)})}
                  placeholder="12"
                />
              </div>
            </div>
            
            <div>
              <Label htmlFor="purpose">Tujuan Pinjaman</Label>
              <Textarea
                id="purpose"
                value={userProfile.purpose}
                onChange={(e) => setUserProfile({...userProfile, purpose: e.target.value})}
                placeholder="Jelaskan tujuan pinjaman Anda..."
                rows={3}
              />
            </div>
            
            <motion.div
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <Button 
                onClick={analyzeProfile}
                disabled={isAnalyzing}
                className="w-full bg-gradient-to-r from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700"
              >
                {isAnalyzing ? (
                  <motion.div
                    animate={{ rotate: 360 }}
                    transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                    className="flex items-center"
                  >
                    <Brain className="w-5 h-5 mr-2" />
                    Menganalisis profil Anda...
                  </motion.div>
                ) : (
                  <div className="flex items-center">
                    <Lightbulb className="w-5 h-5 mr-2" />
                    Dapatkan Rekomendasi AI
                  </div>
                )}
              </Button>
            </motion.div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Recommendations Results */}
      <AnimatePresence>
        {showResults && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.6 }}
            className="space-y-4"
          >
            {recommendations.map((rec, index) => (
              <motion.div
                key={rec.product}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.5, delay: index * 0.2 }}
              >
                <Card className="border-l-4 border-l-purple-500">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="flex items-center">
                        <CheckCircle className="w-5 h-5 mr-2 text-green-500" />
                        {rec.product}
                      </CardTitle>
                      <div className="flex items-center space-x-2">
                        <Badge className={getConfidenceColor(rec.confidence)}>
                          {rec.confidence}% Match
                        </Badge>
                        <div className="text-right">
                          <div className="text-2xl font-bold">
                            {rec.matchScore}%
                          </div>
                          <div className="text-xs text-gray-500">Match Score</div>
                        </div>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {/* Key Metrics */}
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      <div className="text-center">
                        <div className="w-12 h-12 mx-auto mb-2 rounded-full bg-yellow-100 flex items-center justify-center">
                          <DollarSign className="w-6 h-6 text-yellow-600" />
                        </div>
                        <div className="text-2xl font-bold text-gray-900">
                          Rp {rec.estimatedAmount.toLocaleString('id-ID')}
                        </div>
                        <div className="text-sm text-gray-600">Estimasi Amount</div>
                      </div>
                      <div className="text-center">
                        <div className="w-12 h-12 mx-auto mb-2 rounded-full bg-blue-100 flex items-center justify-center">
                          <TrendingUp className="w-6 h-6 text-blue-600" />
                        </div>
                        <div className="text-2xl font-bold text-gray-900">
                          {rec.estimatedRate}%
                        </div>
                        <div className="text-sm text-gray-600">Bunga/Bulan</div>
                      </div>
                      <div className="text-center">
                        <div className="w-12 h-12 mx-auto mb-2 rounded-full bg-purple-100 flex items-center justify-center">
                          <Clock className="w-6 h-6 text-purple-600" />
                        </div>
                        <div className="text-2xl font-bold text-gray-900">
                          {rec.processingTime}
                        </div>
                        <div className="text-sm text-gray-600">Processing Time</div>
                      </div>
                      <div className="text-center">
                        <div className="w-12 h-12 mx-auto mb-2 rounded-full bg-green-100 flex items-center justify-center">
                          <Shield className="w-6 h-6 text-green-600" />
                        </div>
                        <div className="text-2xl font-bold text-gray-900">
                          {rec.confidence}%
                        </div>
                        <div className="text-sm text-gray-600">Confidence</div>
                      </div>
                    </div>
                    
                    {/* AI Reasons */}
                    <div>
                      <h4 className="font-semibold mb-2 flex items-center">
                        <Brain className="w-4 h-4 mr-2 text-purple-600" />
                        AI Analysis Reasons:
                      </h4>
                      <ul className="space-y-1">
                        {rec.reasons.map((reason, idx) => (
                          <li key={idx} className="flex items-start">
                            <CheckCircle className="w-4 h-4 mr-2 text-green-500 flex-shrink-0 mt-0.5" />
                            <span className="text-sm">{reason}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                    
                    {/* Pros and Cons */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <h4 className="font-semibold mb-2 text-green-600">Keuntungan:</h4>
                        <ul className="space-y-1">
                          {rec.pros.map((pro, idx) => (
                            <li key={idx} className="flex items-start">
                              <CheckCircle className="w-4 h-4 mr-2 text-green-500 flex-shrink-0 mt-0.5" />
                              <span className="text-sm">{pro}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                      <div>
                        <h4 className="font-semibold mb-2 text-orange-600">Pertimbangan:</h4>
                        <ul className="space-y-1">
                          {rec.cons.map((con, idx) => (
                            <li key={idx} className="flex items-start">
                              <AlertCircle className="w-4 h-4 mr-2 text-orange-500 flex-shrink-0 mt-0.5" />
                              <span className="text-sm">{con}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                    
                    {/* Action Button */}
                    <motion.div
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                    >
                      <Button 
                        className="w-full bg-gradient-to-r from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700"
                        onClick={() => window.location.href = `/apply?product=${rec.product}&amount=${rec.estimatedAmount}`}
                      >
                        Ajukan {rec.product} Sekarang
                      </Button>
                    </motion.div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}