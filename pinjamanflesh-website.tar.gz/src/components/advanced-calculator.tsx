'use client';

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Calculator, 
  TrendingUp, 
  Calendar, 
  DollarSign, 
  Percent, 
  Clock,
  Download,
  Info,
  CheckCircle,
  AlertCircle
} from 'lucide-react';

interface AmortizationSchedule {
  month: number;
  payment: number;
  principal: number;
  interest: number;
  balance: number;
  totalInterest: number;
}

interface LoanDetails {
  amount: number;
  rate: number;
  term: number;
  monthlyPayment: number;
  totalPayment: number;
  totalInterest: number;
  effectiveRate: number;
}

export function AdvancedCalculator() {
  const [loanAmount, setLoanAmount] = useState(50000000);
  const [interestRate, setInterestRate] = useState(1.5);
  const [loanTerm, setLoanTerm] = useState(24);
  const [amortizationSchedule, setAmortizationSchedule] = useState<AmortizationSchedule[]>([]);
  const [showSchedule, setShowSchedule] = useState(false);
  const [loanDetails, setLoanDetails] = useState<LoanDetails | null>(null);

  const calculateAmortization = () => {
    const monthlyRate = interestRate / 100;
    const monthlyPayment = (loanAmount * monthlyRate * Math.pow(1 + monthlyRate, loanTerm)) / 
                          (Math.pow(1 + monthlyRate, loanTerm) - 1);
    
    const totalPayment = monthlyPayment * loanTerm;
    const totalInterest = totalPayment - loanAmount;
    const effectiveRate = (totalInterest / loanAmount) * 100;

    setLoanDetails({
      amount: loanAmount,
      rate: interestRate,
      term: loanTerm,
      monthlyPayment,
      totalPayment,
      totalInterest,
      effectiveRate
    });

    // Generate amortization schedule
    const schedule: AmortizationSchedule[] = [];
    let balance = loanAmount;
    let totalInterestPaid = 0;

    for (let month = 1; month <= loanTerm; month++) {
      const interestPayment = balance * monthlyRate;
      const principalPayment = monthlyPayment - interestPayment;
      balance -= principalPayment;
      totalInterestPaid += interestPayment;

      schedule.push({
        month,
        payment: monthlyPayment,
        principal: principalPayment,
        interest: interestPayment,
        balance: Math.max(0, balance),
        totalInterest: totalInterestPaid
      });
    }

    setAmortizationSchedule(schedule);
  };

  useEffect(() => {
    calculateAmortization();
  }, [loanAmount, interestRate, loanTerm]);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      minimumFractionDigits: 0
    }).format(amount);
  };

  const exportToCSV = () => {
    const headers = ['Bulan', 'Pembayaran', 'Pokok', 'Bunga', 'Sisa Saldo', 'Total Bunga'];
    const csvContent = [
      headers.join(','),
      ...amortizationSchedule.map(row => 
        [row.month, row.payment, row.principal, row.interest, row.balance, row.totalInterest].join(',')
      )
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'amortization_schedule.csv';
    a.click();
    window.URL.revokeObjectURL(url);
  };

  const getInterestColor = (rate: number) => {
    if (rate <= 1.2) return 'text-green-600';
    if (rate <= 1.5) return 'text-yellow-600';
    return 'text-red-600';
  };

  return (
    <div className="space-y-6">
      {/* Calculator */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Calculator className="w-6 h-6 mr-2 text-blue-600" />
              Advanced Loan Calculator with Amortization
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
              <div>
                <Label htmlFor="amount">Jumlah Pinjaman (Rp)</Label>
                <Input
                  id="amount"
                  type="number"
                  value={loanAmount}
                  onChange={(e) => setLoanAmount(parseInt(e.target.value) || 0)}
                  className="mt-1"
                  placeholder="50000000"
                />
              </div>
              <div>
                <Label htmlFor="rate">Suku Bunga (% per tahun)</Label>
                <Input
                  id="rate"
                  type="number"
                  step="0.1"
                  value={interestRate}
                  onChange={(e) => setInterestRate(parseFloat(e.target.value) || 0)}
                  className="mt-1"
                  placeholder="1.5"
                />
              </div>
              <div>
                <Label htmlFor="term">Jangka Waktu (bulan)</Label>
                <Input
                  id="term"
                  type="number"
                  value={loanTerm}
                  onChange={(e) => setLoanTerm(parseInt(e.target.value) || 0)}
                  className="mt-1"
                  placeholder="24"
                />
              </div>
              <div className="flex items-end">
                <motion.div
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <Button 
                    onClick={calculateAmortization}
                    className="w-full bg-blue-600 hover:bg-blue-700"
                  >
                    <Calculator className="w-4 h-4 mr-2" />
                    Hitung Ulang
                  </Button>
                </motion.div>
              </div>
            </div>

            {/* Quick Presets */}
            <div className="mb-6">
              <h3 className="font-semibold mb-3">Preset Cepat:</h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                {[
                  { amount: 10000000, rate: 1.8, term: 12, label: 'Pinjaman Kilat' },
                  { amount: 50000000, rate: 1.5, term: 24, label: 'Pinjaman Modal' },
                  { amount: 25000000, rate: 1.2, term: 36, label: 'Pinjaman Pendidikan' },
                  { amount: 100000000, rate: 1.3, term: 48, label: 'Bisnis Besar' }
                ].map((preset, index) => (
                  <motion.div
                    key={preset.label}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    <Button
                      variant="outline"
                      size="sm"
                      className="w-full"
                      onClick={() => {
                        setLoanAmount(preset.amount);
                        setInterestRate(preset.rate);
                        setLoanTerm(preset.term);
                      }}
                    >
                      {preset.label}
                    </Button>
                  </motion.div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Results */}
      {loanDetails && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
        >
          <Card>
            <CardHeader>
              <CardTitle>Hasil Perhitungan</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <div className="text-center">
                  <div className="w-12 h-12 mx-auto mb-2 rounded-full bg-blue-100 flex items-center justify-center">
                    <DollarSign className="w-6 h-6 text-blue-600" />
                  </div>
                  <div className="text-2xl font-bold text-gray-900">
                    {formatCurrency(loanDetails.monthlyPayment)}
                  </div>
                  <div className="text-sm text-gray-600">Cicilan/Bulan</div>
                </div>
                <div className="text-center">
                  <div className="w-12 h-12 mx-auto mb-2 rounded-full bg-green-100 flex items-center justify-center">
                    <TrendingUp className="w-6 h-6 text-green-600" />
                  </div>
                  <div className="text-2xl font-bold text-gray-900">
                    {formatCurrency(loanDetails.totalPayment)}
                  </div>
                  <div className="text-sm text-gray-600">Total Pembayaran</div>
                </div>
                <div className="text-center">
                  <div className="w-12 h-12 mx-auto mb-2 rounded-full bg-yellow-100 flex items-center justify-center">
                    <Percent className="w-6 h-6 text-yellow-600" />
                  </div>
                  <div className={`text-2xl font-bold ${getInterestColor(loanDetails.rate)}`}>
                    {loanDetails.effectiveRate.toFixed(1)}%
                  </div>
                  <div className="text-sm text-gray-600">Bunga Efektif</div>
                </div>
                <div className="text-center">
                  <div className="w-12 h-12 mx-auto mb-2 rounded-full bg-purple-100 flex items-center justify-center">
                    <Calendar className="w-6 h-6 text-purple-600" />
                  </div>
                  <div className="text-2xl font-bold text-gray-900">
                    {loanDetails.term}
                  </div>
                  <div className="text-sm text-gray-600">Jangka Waktu (bulan)</div>
                </div>
              </div>

              {/* Summary Info */}
              <div className="mt-6 p-4 bg-blue-50 rounded-lg">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <div className="flex items-center mb-2">
                      <Info className="w-4 h-4 text-blue-500 mr-2" />
                      <span className="font-semibold">Detail Pinjaman</span>
                    </div>
                    <div className="space-y-1 text-sm">
                      <div>Amount: {formatCurrency(loanDetails.amount)}</div>
                      <div>Rate: {loanDetails.rate}% per tahun</div>
                      <div>Term: {loanDetails.term} bulan</div>
                    </div>
                  </div>
                  <div>
                    <div className="flex items-center mb-2">
                      <CheckCircle className="w-4 h-4 text-green-500 mr-2" />
                      <span className="font-semibold">Breakdown Pembayaran</span>
                    </div>
                    <div className="space-y-1 text-sm">
                      <div>Monthly: {formatCurrency(loanDetails.monthlyPayment)}</div>
                      <div>Total: {formatCurrency(loanDetails.totalPayment)}</div>
                      <div>Interest: {formatCurrency(loanDetails.totalInterest)}</div>
                    </div>
                  </div>
                  <div>
                    <div className="flex items-center mb-2">
                      <AlertCircle className="w-4 h-4 text-yellow-500 mr-2" />
                      <span className="font-semibold">Analisis</span>
                    </div>
                    <div className="space-y-1 text-sm">
                      <div className={getInterestColor(loanDetails.rate)}>
                        {loanDetails.rate <= 1.2 ? '✓ Sangat kompetitif' :
                         loanDetails.rate <= 1.5 ? '✓ Kompetitif' : '⚠ Rate tinggi'}
                      </div>
                      <div>Eff. Rate: {loanDetails.effectiveRate.toFixed(2)}%</div>
                      <div>Total Interest: {((loanDetails.totalInterest / loanDetails.totalPayment) * 100).toFixed(1)}%</div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex space-x-4 mt-6">
                <motion.div
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <Button 
                    onClick={() => setShowSchedule(!showSchedule)}
                    className="bg-purple-600 hover:bg-purple-700"
                  >
                    <Calendar className="w-4 h-4 mr-2" />
                    {showSchedule ? 'Sembunyikan' : 'Tampilkan'} Jadwal
                  </Button>
                </motion.div>
                <motion.div
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <Button 
                    onClick={exportToCSV}
                    variant="outline"
                    className="flex items-center"
                  >
                    <Download className="w-4 h-4 mr-2" />
                    Export CSV
                  </Button>
                </motion.div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      )}

      {/* Amortization Schedule */}
      <AnimatePresence>
        {showSchedule && amortizationSchedule.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.6 }}
          >
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <div className="flex items-center">
                    <Calendar className="w-6 h-6 mr-2 text-purple-600" />
                    Jadwal Amortisasi
                  </div>
                  <Badge className="bg-purple-100 text-purple-800">
                    {amortizationSchedule.length} bulan
                  </Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full border-collapse">
                    <thead>
                      <tr className="border-b bg-gray-50">
                        <th className="text-left p-3 font-semibold">Bulan</th>
                        <th className="text-right p-3 font-semibold">Pembayaran</th>
                        <th className="text-right p-3 font-semibold">Pokok</th>
                        <th className="text-right p-3 font-semibold">Bunga</th>
                        <th className="text-right p-3 font-semibold">Sisa Saldo</th>
                        <th className="text-right p-3 font-semibold">Total Bunga</th>
                      </tr>
                    </thead>
                    <tbody>
                      {amortizationSchedule.map((row, index) => (
                        <motion.tr
                          key={row.month}
                          className="border-b hover:bg-gray-50"
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ duration: 0.3, delay: index * 0.02 }}
                        >
                          <td className="p-3 font-medium">{row.month}</td>
                          <td className="p-3 text-right">{formatCurrency(row.payment)}</td>
                          <td className="p-3 text-right">{formatCurrency(row.principal)}</td>
                          <td className="p-3 text-right">{formatCurrency(row.interest)}</td>
                          <td className="p-3 text-right font-semibold">{formatCurrency(row.balance)}</td>
                          <td className="p-3 text-right">{formatCurrency(row.totalInterest)}</td>
                        </motion.tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}