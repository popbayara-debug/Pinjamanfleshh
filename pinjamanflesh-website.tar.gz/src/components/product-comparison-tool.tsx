'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  ArrowUpDown, 
  CheckCircle, 
  XCircle, 
  Info, 
  TrendingUp, 
  DollarSign, 
  Clock, 
  Shield,
  Star,
  Award
} from 'lucide-react';

interface ProductFeature {
  name: string;
  kilat: string | boolean;
  modal: string | boolean;
  pendidikan: string | boolean;
}

interface ComparisonData {
  category: string;
  kilat: string;
  modal: string;
  pendidikan: string;
  important: boolean;
}

export function ProductComparisonTool() {
  const [selectedProducts, setSelectedProducts] = useState<string[]>(['Pinjaman Kilat', 'Pinjaman Modal']);
  const [comparisonView, setComparisonView] = useState<'features' | 'numbers'>('features');

  const allProducts = ['Pinjaman Kilat', 'Pinjaman Modal', 'Pinjaman Pendidikan'];

  const features: ProductFeature[] = [
    {
      name: 'Maksimum Pinjaman',
      kilat: 'Rp 50.000.000',
      modal: 'Rp 500.000.000',
      pendidikan: 'Rp 100.000.000'
    },
    {
      name: 'Suku Bunga',
      kilat: '1.8% per bulan',
      modal: '1.5% per bulan',
      pendidikan: '1.2% per bulan'
    },
    {
      name: 'Waktu Proses',
      kilat: '24 jam',
      modal: '3-5 hari',
      pendidikan: '2-3 hari'
    },
    {
      name: 'Jangka Waktu',
      kilat: '1-12 bulan',
      modal: '6-36 bulan',
      pendidikan: '12-48 bulan'
    },
    {
      name: 'Jaminan Diperlukan',
      kilat: false,
      modal: true,
      pendidikan: false
    },
    {
      name: 'Grace Period',
      kilat: false,
      modal: false,
      pendidikan: true
    },
    {
      name: 'Biaya Admin',
      kilat: 'Rp 150.000',
      modal: 'Rp 250.000',
      pendidikan: 'Rp 100.000'
    },
    {
      name: 'Penalti Pelunasan Dini',
      kilat: '3%',
      modal: '2%',
      pendidikan: '1%'
    },
    {
      name: 'Asuransi',
      kilat: 'Opsional',
      modal: 'Wajib',
      pendidikan: 'Opsional'
    },
    {
      name: 'Flexibel Cicilan',
      kilat: false,
      modal: true,
      pendidikan: true
    }
  ];

  const getFeatureIcon = (value: string | boolean) => {
    if (typeof value === 'boolean') {
      return value ? (
        <CheckCircle className="w-5 h-5 text-green-500" />
      ) : (
        <XCircle className="w-5 h-5 text-red-500" />
      );
    }
    return <span className="font-medium">{value}</span>;
  };

  const getBestValue = (feature: ProductFeature) => {
    const values = [
      { product: 'kilat', value: feature.kilat },
      { product: 'modal', value: feature.modal },
      { product: 'pendidikan', value: feature.pendidikan }
    ];

    // For numerical values, find the best
    if (feature.name.includes('Rp') || feature.name.includes('%')) {
      const numericValues = values.map(v => ({
        ...v,
        numeric: parseFloat(String(v.value).replace(/[^0-9.]/g, ''))
      })).filter(v => !isNaN(v.numeric));
      
      if (numericValues.length > 0) {
        if (feature.name.includes('Bunga') || feature.name.includes('Penalti')) {
          const min = Math.min(...numericValues.map(v => v.numeric));
          return numericValues.find(v => v.numeric === min)?.product;
        } else {
          const max = Math.max(...numericValues.map(v => v.numeric));
          return numericValues.find(v => v.numeric === max)?.product;
        }
      }
    }

    // For boolean values, true is better
    if (typeof feature.kilat === 'boolean') {
      const trueValues = values.filter(v => v.value === true);
      if (trueValues.length === 1) {
        return trueValues[0].product;
      }
    }

    // For time, shorter is better
    if (feature.name.includes('jam') || feature.name.includes('hari')) {
      // This is simplified - in real app would parse time properly
      return 'kilat'; // Fastest is usually best
    }

    return null;
  };

  const getWinnerBadge = (product: string, feature: ProductFeature) => {
    const best = getBestValue(feature);
    if (best === product) {
      return (
        <Badge className="bg-green-100 text-green-800 ml-2">
          <Award className="w-3 h-3 mr-1" />
          Terbaik
        </Badge>
      );
    }
    return null;
  };

  const getProductScore = (productName: string) => {
    let score = 0;
    let totalWeight = 0;

    features.forEach(feature => {
      let weight = 1;
      let featureScore = 0;

      if (feature.name.includes('Maksimum')) weight = 3;
      if (feature.name.includes('Bunga')) weight = 3;
      if (feature.name.includes('Waktu Proses')) weight = 2;
      if (feature.name.includes('Jaminan')) weight = 2;
      if (feature.name.includes('Grace Period')) weight = 1;

      const best = getBestValue(feature);
      const productValue = feature[productName.toLowerCase().replace('pinjaman ', '') as keyof Omit<ProductFeature, 'name'>];
      
      if (best === productName) {
        featureScore = 100;
      } else {
        featureScore = 60; // Base score for non-winners
      }

      score += featureScore * weight;
      totalWeight += 100 * weight;
    });

    return Math.round((score / totalWeight) * 100);
  };

  const toggleProduct = (product: string) => {
    if (selectedProducts.includes(product)) {
      setSelectedProducts(selectedProducts.filter(p => p !== product));
    } else if (selectedProducts.length < 3) {
      setSelectedProducts([...selectedProducts, product]);
    }
  };

  return (
    <div className="space-y-6">
      {/* Product Selector */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <ArrowUpDown className="w-6 h-6 mr-2 text-blue-600" />
              Product Comparison Tool
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <h3 className="font-semibold mb-3">Pilih Produk untuk Dibandingkan:</h3>
                <div className="flex flex-wrap gap-3">
                  {allProducts.map(product => (
                    <motion.div
                      key={product}
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                    >
                      <Button
                        variant={selectedProducts.includes(product) ? "default" : "outline"}
                        onClick={() => toggleProduct(product)}
                        disabled={!selectedProducts.includes(product) && selectedProducts.length >= 3}
                        className="relative"
                      >
                        {selectedProducts.includes(product) && (
                          <CheckCircle className="w-4 h-4 mr-2" />
                        )}
                        {product}
                        {selectedProducts.includes(product) && (
                          <Badge className="ml-2 bg-green-100 text-green-800">
                            {getProductScore(product)}%
                          </Badge>
                        )}
                      </Button>
                    </motion.div>
                  ))}
                </div>
              </div>

              <div className="flex items-center space-x-4">
                <div className="flex items-center">
                  <Info className="w-4 h-4 mr-2 text-blue-500" />
                  <span className="text-sm text-gray-600">
                    Skor berdasarkan perbandingan fitur, bunga, dan keuntungan
                  </span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Comparison Results */}
      {selectedProducts.length >= 2 && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
        >
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Hasil Perbandingan</CardTitle>
                <div className="flex space-x-2">
                  <Button
                    variant={comparisonView === 'features' ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setComparisonView('features')}
                  >
                    Fitur
                  </Button>
                  <Button
                    variant={comparisonView === 'numbers' ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setComparisonView('numbers')}
                  >
                    Angka
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full border-collapse">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left p-3 font-semibold">Fitur</th>
                      {selectedProducts.map(product => (
                        <th key={product} className="text-center p-3 font-semibold">
                          <div className="flex flex-col items-center">
                            {product}
                            <Badge className="mt-1 bg-blue-100 text-blue-800">
                              {getProductScore(product)}%
                            </Badge>
                          </div>
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {features.map((feature, index) => (
                      <motion.tr
                        key={feature.name}
                        className="border-b hover:bg-gray-50"
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ duration: 0.3, delay: index * 0.1 }}
                      >
                        <td className="p-3 font-medium">
                          <div className="flex items-center">
                            {feature.name}
                            {feature.name.includes('Maksimum') || 
                             feature.name.includes('Bunga') || 
                             feature.name.includes('Waktu Proses') ? (
                              <Star className="w-4 h-4 ml-2 text-yellow-500" />
                            ) : null}
                          </div>
                        </td>
                        {selectedProducts.map(product => {
                          const value = feature[product.toLowerCase().replace('pinjaman ', '') as keyof Omit<ProductFeature, 'name'>];
                          const isWinner = getBestValue(feature) === product;
                          
                          return (
                            <td key={product} className={`p-3 text-center ${isWinner ? 'bg-green-50' : ''}`}>
                              <div className="flex items-center justify-center">
                                {getFeatureIcon(value)}
                                {isWinner && getWinnerBadge(product, feature)}
                              </div>
                            </td>
                          );
                        })}
                      </motion.tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Summary */}
              <div className="mt-6 p-4 bg-blue-50 rounded-lg">
                <h3 className="font-semibold mb-3 flex items-center">
                  <TrendingUp className="w-5 h-5 mr-2 text-blue-600" />
                  Kesimpulan AI
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {selectedProducts.map(product => {
                    const score = getProductScore(product);
                    const isHighest = score === Math.max(...selectedProducts.map(p => getProductScore(p)));
                    
                    return (
                      <motion.div
                        key={product}
                        className={`p-3 rounded-lg border-2 ${
                          isHighest ? 'border-green-500 bg-green-50' : 'border-gray-300 bg-white'
                        }`}
                        whileHover={{ scale: 1.02 }}
                      >
                        <div className="text-center">
                          <div className="font-semibold">{product}</div>
                          <div className={`text-2xl font-bold ${isHighest ? 'text-green-600' : 'text-gray-600'}`}>
                            {score}%
                          </div>
                          <div className="text-sm text-gray-500">
                            {isHighest ? 'Pilihan Terbaik' : 'Skor Komprehensif'}
                          </div>
                        </div>
                      </motion.div>
                    );
                  })}
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      )}
    </div>
  );
}