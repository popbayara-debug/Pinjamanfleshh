'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Play, 
  Star, 
  Quote, 
  ThumbsUp, 
  MessageCircle, 
  User,
  Calendar,
  CheckCircle,
  TrendingUp
} from 'lucide-react';

interface Testimonial {
  id: string;
  name: string;
  profession: string;
  avatar: string;
  rating: number;
  date: string;
  content: string;
  videoUrl?: string;
  product: string;
  amount: number;
  approved: boolean;
  helpful: number;
  verified: boolean;
}

export function AdvancedTestimonials() {
  const [selectedFilter, setSelectedFilter] = useState<'all' | 'video' | 'text'>('all');
  const [playingVideo, setPlayingVideo] = useState<string | null>(null);

  const testimonials: Testimonial[] = [
    {
      id: '1',
      name: 'Budi Santoso',
      profession: 'Pengusaha Restoran',
      avatar: '/avatars/budi.jpg',
      rating: 5,
      date: '2024-01-15',
      content: 'PinjamanFlesh membantu saya mengembangkan bisnis restoran saya. Prosesnya sangat cepat, hanya 2 hari sudah cair. Saya dapat pinjaman modal Rp 100 juta dengan bunga yang sangat kompetitif. Pelayanan customer service juga sangat baik dan responsif.',
      videoUrl: '/videos/testimonial-budi.mp4',
      product: 'Pinjaman Modal',
      amount: 100000000,
      approved: true,
      helpful: 45,
      verified: true
    },
    {
      id: '2',
      name: 'Siti Nurhaliza',
      profession: 'Ibu Rumah Tangga',
      avatar: '/avatars/siti.jpg',
      rating: 5,
      date: '2024-01-20',
      content: 'Saya sangat puas dengan layanan PinjamanFlesh. Saat saya butuh dana darurat untuk biaya sekolah anak, proses pengajuannya mudah dan cepat. Dana cair dalam 24 jam. Bunganya juga terjangkau. Terima kasih PinjamanFlesh!',
      product: 'Pinjaman Kilat',
      amount: 15000000,
      approved: true,
      helpful: 38,
      verified: true
    },
    {
      id: '3',
      name: 'Ahmad Fauzi',
      profession: 'Karyawan Swasta',
      avatar: '/avatars/ahmad.jpg',
      rating: 4,
      date: '2024-01-25',
      content: 'Saya mengajukan pinjaman pendidikan untuk S2 saya. Prosesnya transparan dan tidak ada biaya tersembunyi. Grace period yang diberikan sangat membantu. Recommended banget untuk yang butuh pinjaman pendidikan!',
      videoUrl: '/videos/testimonial-ahmad.mp4',
      product: 'Pinjaman Pendidikan',
      amount: 50000000,
      approved: true,
      helpful: 52,
      verified: true
    },
    {
      id: '4',
      name: 'Dewi Lestari',
      profession: 'Entrepreneur',
      avatar: '/avatars/dewi.jpg',
      rating: 5,
      date: '2024-02-01',
      content: 'Sebagai entrepreneur, saya sering butuh modal cepat. PinjamanFlesh selalu menjadi pilihan pertama saya. Proses approval cepat, documentation simple, dan rate yang bersaing. Sudah 3 kali saya pinjam di sini, selalu puas dengan pelayanannya.',
      product: 'Pinjaman Kilat',
      amount: 25000000,
      approved: true,
      helpful: 67,
      verified: true
    },
    {
      id: '5',
      name: 'Rudi Hermawan',
      profession: 'Pemilik Toko',
      avatar: '/avatars/rudi.jpg',
      rating: 4,
      date: '2024-02-05',
      content: 'Pinjaman modal dari PinjamanFlesh sangat membantu bisnis saya berkembang. Jangka waktu pembayaran yang fleksibel membuat saya tidak terbebani. Bunga juga lebih rendah dibandingkan tempat lain.',
      videoUrl: '/videos/testimonial-rudi.mp4',
      product: 'Pinjaman Modal',
      amount: 75000000,
      approved: true,
      helpful: 41,
      verified: true
    },
    {
      id: '6',
      name: 'Maya Sari',
      profession: 'Mahasiswa',
      avatar: '/avatars/maya.jpg',
      rating: 5,
      date: '2024-02-10',
      content: 'Saya mahasiswa dan butuh biaya kuliah. Pinjaman pendidikan dari PinjamanFlesh solusi yang tepat. Grace period 6 bulan sangat membantu. Proses pengajuannya online jadi tidak perlu ke kantor.',
      product: 'Pinjaman Pendidikan',
      amount: 20000000,
      approved: true,
      helpful: 29,
      verified: true
    }
  ];

  const filteredTestimonials = testimonials.filter(testimonial => {
    if (selectedFilter === 'video') return testimonial.videoUrl;
    if (selectedFilter === 'text') return !testimonial.videoUrl;
    return true;
  });

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star
        key={i}
        className={`w-4 h-4 ${
          i < rating ? 'text-yellow-400 fill-current' : 'text-gray-300'
        }`}
      />
    ));
  };

  const averageRating = testimonials.reduce((acc, t) => acc + t.rating, 0) / testimonials.length;
  const totalApproved = testimonials.filter(t => t.approved).length;
  const totalAmount = testimonials.reduce((acc, t) => acc + t.amount, 0);

  return (
    <div className="space-y-6">
      {/* Stats Overview */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <Card>
          <CardContent className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <div className="text-center">
                <div className="flex items-center justify-center mb-2">
                  <Star className="w-6 h-6 text-yellow-400 mr-2" />
                  <div className="text-2xl font-bold">{averageRating.toFixed(1)}</div>
                </div>
                <div className="text-sm text-gray-600">Rating Rata-rata</div>
              </div>
              <div className="text-center">
                <div className="flex items-center justify-center mb-2">
                  <CheckCircle className="w-6 h-6 text-green-500 mr-2" />
                  <div className="text-2xl font-bold">{totalApproved}</div>
                </div>
                <div className="text-sm text-gray-600">Pinjaman Disetujui</div>
              </div>
              <div className="text-center">
                <div className="flex items-center justify-center mb-2">
                  <TrendingUp className="w-6 h-6 text-blue-500 mr-2" />
                  <div className="text-2xl font-bold">Rp {(totalAmount / 1000000).toFixed(0)}M</div>
                </div>
                <div className="text-sm text-gray-600">Total Dipinjam</div>
              </div>
              <div className="text-center">
                <div className="flex items-center justify-center mb-2">
                  <MessageCircle className="w-6 h-6 text-purple-500 mr-2" />
                  <div className="text-2xl font-bold">{testimonials.length}</div>
                </div>
                <div className="text-sm text-gray-600">Total Testimoni</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Filter Tabs */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.1 }}
      >
        <div className="flex justify-center space-x-4 mb-8">
          {[
            { key: 'all', label: 'Semua', count: testimonials.length },
            { key: 'video', label: 'Video', count: testimonials.filter(t => t.videoUrl).length },
            { key: 'text', label: 'Text', count: testimonials.filter(t => !t.videoUrl).length }
          ].map(filter => (
            <motion.div
              key={filter.key}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <Button
                variant={selectedFilter === filter.key ? 'default' : 'outline'}
                onClick={() => setSelectedFilter(filter.key as any)}
                className="relative"
              >
                {filter.label}
                <Badge className="ml-2 bg-blue-100 text-blue-800">
                  {filter.count}
                </Badge>
              </Button>
            </motion.div>
          ))}
        </div>
      </motion.div>

      {/* Testimonials Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredTestimonials.map((testimonial, index) => (
          <motion.div
            key={testimonial.id}
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: index * 0.1 }}
          >
            <Card className="hover:shadow-lg transition-all duration-300 group">
              <CardContent className="p-6">
                {/* Header */}
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center">
                    <div className="w-12 h-12 bg-gray-200 rounded-full mr-3 overflow-hidden">
                      <img
                        src={testimonial.avatar}
                        alt={testimonial.name}
                        className="w-full h-full object-cover"
                        onError={(e) => {
                          (e.target as HTMLImageElement).src = `https://ui-avatars.com/api/?name=${testimonial.name}&background=random`;
                        }}
                      />
                    </div>
                    <div>
                      <div className="flex items-center">
                        <h3 className="font-semibold">{testimonial.name}</h3>
                        {testimonial.verified && (
                          <CheckCircle className="w-4 h-4 text-blue-500 ml-2" />
                        )}
                      </div>
                      <p className="text-sm text-gray-600">{testimonial.profession}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="flex items-center mb-1">
                      {renderStars(testimonial.rating)}
                    </div>
                    <p className="text-xs text-gray-500">{testimonial.date}</p>
                  </div>
                </div>

                {/* Video or Content */}
                {testimonial.videoUrl ? (
                  <div className="mb-4">
                    {playingVideo === testimonial.id ? (
                      <div className="relative bg-black rounded-lg overflow-hidden" style={{ paddingBottom: '56.25%' }}>
                        <video
                          className="absolute inset-0 w-full h-full"
                          controls
                          autoPlay
                          src={testimonial.videoUrl}
                        />
                      </div>
                    ) : (
                      <motion.div
                        className="relative bg-gray-100 rounded-lg overflow-hidden cursor-pointer group"
                        style={{ paddingBottom: '56.25%' }}
                        whileHover={{ scale: 1.02 }}
                        onClick={() => setPlayingVideo(testimonial.id)}
                      >
                        <img
                          src={testimonial.videoUrl.replace('.mp4', '-thumb.jpg')}
                          alt="Video thumbnail"
                          className="absolute inset-0 w-full h-full object-cover"
                        />
                        <div className="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center">
                          <motion.div
                            className="w-12 h-12 bg-white rounded-full flex items-center justify-center"
                            whileHover={{ scale: 1.1 }}
                          >
                            <Play className="w-6 h-6 text-gray-800 ml-1" />
                          </motion.div>
                        </div>
                        <Badge className="absolute top-2 left-2 bg-red-500 text-white">
                          VIDEO
                        </Badge>
                      </motion.div>
                    )}
                  </div>
                ) : (
                  <div className="mb-4">
                    <Quote className="w-8 h-8 text-gray-300 mb-2" />
                    <p className="text-gray-700 italic leading-relaxed">
                      "{testimonial.content}"
                    </p>
                  </div>
                )}

                {/* Product Info */}
                <div className="flex items-center justify-between mb-4">
                  <Badge variant="secondary">
                    {testimonial.product}
                  </Badge>
                  <div className="text-sm text-gray-600">
                    Rp {testimonial.amount.toLocaleString('id-ID')}
                  </div>
                </div>

                {/* Actions */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <motion.div
                      whileHover={{ scale: 1.1 }}
                      whileTap={{ scale: 0.9 }}
                    >
                      <Button
                        variant="ghost"
                        size="sm"
                        className="flex items-center"
                      >
                        <ThumbsUp className="w-4 h-4 mr-1" />
                        {testimonial.helpful}
                      </Button>
                    </motion.div>
                    <motion.div
                      whileHover={{ scale: 1.1 }}
                      whileTap={{ scale: 0.9 }}
                    >
                      <Button
                        variant="ghost"
                        size="sm"
                        className="flex items-center"
                      >
                        <MessageCircle className="w-4 h-4 mr-1" />
                        Balas
                      </Button>
                    </motion.div>
                  </div>
                  {testimonial.approved && (
                    <Badge className="bg-green-100 text-green-800">
                      <CheckCircle className="w-3 h-3 mr-1" />
                      Disetujui
                    </Badge>
                  )}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* Load More */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.8 }}
        className="text-center"
      >
        <Button variant="outline" className="bg-white">
          Muat Lebih Banyak Testimoni
        </Button>
      </motion.div>
    </div>
  );
}