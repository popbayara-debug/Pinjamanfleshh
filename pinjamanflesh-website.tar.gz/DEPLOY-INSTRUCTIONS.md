# Deployment Instructions

## Quick Deploy Options

### Option 1: Docker Deployment (Recommended)

```bash
# Build and run with Docker Compose
docker-compose up -d

# Check status
docker-compose ps

# View logs
docker-compose logs -f
```

### Option 2: Manual Deployment

```bash
# Production deployment
npm run build
npm start

# Development deployment  
npm run dev
```

### Option 3: Using Deploy Script

```bash
# Deploy to production
./deploy.sh production

# Deploy to development
./deploy.sh development
```

## Platform-Specific Deployment

### Vercel (Easiest)
1. Push to GitHub
2. Import ke Vercel
3. Setup environment variables
4. Auto-deploy

### Railway/Render
1. Connect GitHub
2. Build: `npm run build`
3. Start: `npm start`
4. Setup env vars

### VPS/Dedicated Server
1. Install Node.js 18+
2. Clone repository
3. Run deployment script
4. Setup reverse proxy (nginx)

## Environment Variables Required

Copy `.env.production` to `.env` and update:

```env
NODE_ENV=production
NEXTAUTH_URL=https://yourdomain.com
NEXTAUTH_SECRET=your-secret-key
DATABASE_URL=file:./db/production.db
WHATSAPP_NUMBER=6285892803452
```

## Post-Deployment Checklist

- [ ] Website accessible at domain
- [ ] All forms working
- [ ] WhatsApp integration functional
- [ ] Mobile responsive test
- [ ] SSL certificate installed
- [ ] Performance test passed
- [ ] Error monitoring setup