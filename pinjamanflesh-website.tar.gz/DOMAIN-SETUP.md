# Custom Domain Setup Guide for PinjamanFlesh

## 🌐 Domain Configuration Options

### Option 1: Free Vercel Subdomain
- **URL**: `pinjamanflesh.vercel.app`
- **Cost**: Free
- **Setup**: Automatic
- **SSL**: Automatic

### Option 2: Custom Domain
- **URL**: `pinjamanflesh.com`
- **Cost**: Domain registration (~$12/year)
- **Setup**: Manual DNS configuration
- **SSL**: Free via Vercel

## 📋 Step-by-Step Custom Domain Setup

### 1. Purchase Domain (If needed)

Recommended registrars:
- **Namecheap**: namecheap.com
- **GoDaddy**: godaddy.com
- **Google Domains**: domains.google.com
- **Cloudflare**: cloudflare.com

### 2. Configure in Vercel

1. **Go to Vercel Dashboard**
2. **Select your project**
3. **Click "Settings" tab**
4. **Click "Domains"**
5. **Add custom domain**: `pinjamanflesh.com`
6. **Click "Add"**

### 3. DNS Configuration

#### Method A: CNAME Record (Recommended)
```
Type: CNAME
Name: @ (or pinjamanflesh)
Value: cname.vercel-dns.com
TTL: 300 (Automatic)
```

#### Method B: A Record
```
Type: A
Name: @ (or pinjamanflesh)
Value: 76.76.21.21
TTL: 300 (Automatic)
```

#### Method C: WWW Subdomain
```
Type: CNAME
Name: www
Value: cname.vercel-dns.com
TTL: 300 (Automatic)
```

### 4. DNS Propagation

- **Time**: 24-48 hours
- **Check**: Use whatsmydns.net
- **Verify**: dig command

```bash
# Check CNAME propagation
dig pinjamanflesh.com CNAME

# Check A record
dig pinjamanflesh.com A
```

## 🔧 Domain Registrar Specific Instructions

### Namecheap
1. **Login to Namecheap**
2. **Go to Domain List**
3. **Click "Manage"**
4. **Go to "Advanced DNS"**
5. **Add CNAME Record**:
   - Type: CNAME Record
   - Host: @
   - Value: cname.vercel-dns.com
   - TTL: Automatic

### GoDaddy
1. **Login to GoDaddy**
2. **Go to "DNS Management"**
3. **Add Record**:
   - Type: CNAME
   - Name: @
   - Value: cname.vercel-dns.com
   - TTL: 1 Hour

### Cloudflare
1. **Login to Cloudflare**
2. **Select domain**
3. **Add CNAME Record**:
   - Type: CNAME
   - Name: @
   - Target: cname.vercel-dns.com
   - Proxy status: Enabled (orange cloud)
   - TTL: Auto

## 🔒 SSL Certificate Setup

### Automatic SSL (Vercel)
- **Free**: Yes
- **Auto-renewal**: Yes
- **Setup**: Automatic
- **Validity**: 90 days

### Manual SSL (Optional)
Only needed if:
- Using external load balancer
- Special SSL requirements
- Extended Validation (EV) certificates

## 📱 Subdomain Options

### Common Subdomains
```
www.pinjamanflesh.com     → Main website
app.pinjamanflesh.com     → Web application
api.pinjamanflesh.com     → API endpoints
blog.pinjamanflesh.com    → Blog/Content
dashboard.pinjamanflesh.com → Admin dashboard
```

### Setup Multiple Subdomains
```bash
# Add each subdomain in Vercel
vercel --prod
# Add: app.pinjamanflesh.com
# Add: api.pinjamanflesh.com
# Add: blog.pinjamanflesh.com
```

## 🌍 International Domains

### Country-Specific Domains
```
pinjamanflesh.id          → Indonesia
pinjamanflesh.co.id       → Indonesia (company)
pinjamanflesh.sg          → Singapore
pinjamanflesh.my          → Malaysia
```

### Multi-Region Setup
1. **Add each domain to Vercel**
2. **Configure DNS separately**
3. **Set up redirects if needed**

## 🔄 Domain Redirects

### WWW to Non-WWW
```javascript
// next.config.js
module.exports = {
  async redirects() {
    return [
      {
        source: '/:path*',
        has: [
          {
            type: 'host',
            value: 'www.pinjamanflesh.com',
          },
        ],
        destination: 'https://pinjamanflesh.com/:path*',
        permanent: true,
      },
    ];
  },
};
```

### HTTP to HTTPS
Automatic with Vercel SSL.

## 📊 Domain Monitoring

### Uptime Monitoring
```bash
# Using Uptime Robot (Free)
# Add: https://pinjamanflesh.com
# Check interval: 5 minutes
# Alert: Email/SMS
```

### SSL Monitoring
```bash
# Check SSL certificate
openssl s_client -connect pinjamanflesh.com:443

# SSL checker tools
# - sslshopper.com/ssl-checker
# - ssllabs.com/ssltest
```

## 🔍 DNS Troubleshooting

### Common Issues

1. **DNS Not Propagating**
   - Wait 24-48 hours
   - Check with whatsmydns.net
   - Clear local DNS cache

2. **CNAME Not Working**
   - Verify record format
   - Check for conflicting records
   - Ensure TTL is set correctly

3. **SSL Not Working**
   - Wait for DNS propagation
   - Check CNAME is correct
   - Verify domain ownership

### Debug Commands
```bash
# Check DNS resolution
nslookup pinjamanflesh.com
dig pinjamanflesh.com ANY

# Check SSL certificate
curl -I https://pinjamanflesh.com

# Trace DNS path
traceroute pinjamanflesh.com
```

## 📋 Domain Setup Checklist

### Pre-Setup Checklist
- [ ] Domain purchased and accessible
- [ ] Domain unlocked (if transferring)
- [ ] Privacy protection configured
- [ ] Auto-renewal enabled

### Post-Setup Checklist
- [ ] DNS records configured correctly
- [ ] SSL certificate active
- [ ] Website accessible via domain
- [ ] WWW redirect working
- [ ] Email forwarding setup (if needed)
- [ ] Domain monitoring active

### Security Checklist
- [ ] DNSSEC enabled (if supported)
- [ ] Domain privacy protection
- [ ] Two-factor authentication on registrar
- [ ] Regular backup of DNS settings

## 🆘 Emergency Procedures

### Domain Issues
1. **Website Down**
   - Check Vercel status
   - Verify DNS records
   - Check SSL certificate

2. **DNS Hijacking**
   - Change registrar password
   - Update DNS records
   - Enable two-factor auth

3. **SSL Issues**
   - Force SSL renewal in Vercel
   - Check DNS configuration
   - Contact Vercel support

---

**🌐 Your custom domain will make PinjamanFlesh look more professional and trustworthy!**