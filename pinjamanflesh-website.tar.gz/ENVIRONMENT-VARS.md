# Environment Variables Configuration for Vercel

## 📋 Required Environment Variables

Copy these variables to your Vercel project settings:

### Core Configuration
```
NODE_ENV=production
NEXTAUTH_URL=https://your-domain.vercel.app
NEXTAUTH_SECRET=your-super-secret-key-generate-random-string-here
```

### Database Configuration
```
DATABASE_URL=file:./db/production.db
```

### Business Configuration
```
WHATSAPP_NUMBER=6285892803452
```

### Optional Configuration
```
ZAI_API_KEY=your-z-ai-api-key-here
NEXT_PUBLIC_APP_URL=https://your-domain.vercel.app
```

## 🔐 Security Notes

### NEXTAUTH_SECRET Generation
Generate secure random string:

```bash
# Method 1: OpenSSL
openssl rand -base64 32

# Method 2: Node.js
node -e "console.log(require('crypto').randomBytes(32).toString('base64'))"

# Method 3: Online generator
# Visit: https://generate-secret.vercel.app/
```

### NEXTAUTH_URL
- **Development**: `http://localhost:3000`
- **Staging**: `https://your-project-name.vercel.app`
- **Production**: `https://your-custom-domain.com`

## 📝 How to Add to Vercel

### Method 1: Vercel Dashboard

1. **Go to Vercel Project**
2. **Click "Settings" tab**
3. **Select "Environment Variables"**
4. **Add each variable:**
   - Name: `NODE_ENV`
   - Value: `production`
   - Environments: `Production`, `Preview`, `Development`
5. **Repeat for all variables**

### Method 2: Vercel CLI

```bash
# Install Vercel CLI
npm i -g vercel

# Login
vercel login

# Add environment variables
vercel env add NODE_ENV
vercel env add NEXTAUTH_URL
vercel env add NEXTAUTH_SECRET
vercel env add DATABASE_URL
vercel env add WHATSAPP_NUMBER

# Pull environment variables locally
vercel env pull .env.production
```

### Method 3: vercel.json (Not recommended for secrets)

```json
{
  "env": {
    "NODE_ENV": "production"
  }
}
```

## 🚨 Important Security Practices

### ✅ Do's
- Use strong, random secrets
- Rotate secrets regularly
- Use different secrets for each environment
- Limit access to secrets

### ❌ Don'ts
- Commit secrets to Git
- Use predictable secrets
- Share secrets in plain text
- Use the same secret across projects

## 🔄 Environment-Specific Values

### Development
```
NODE_ENV=development
NEXTAUTH_URL=http://localhost:3000
DATABASE_URL=file:./db/dev.db
```

### Preview (Vercel Preview Deployments)
```
NODE_ENV=development
NEXTAUTH_URL=https://your-project-name-git-branch.vercel.app
DATABASE_URL=file:./db/preview.db
```

### Production
```
NODE_ENV=production
NEXTAUTH_URL=https://your-domain.com
DATABASE_URL=file:./db/production.db
```

## 🧪 Testing Environment Variables

### Local Testing
```bash
# Copy production env locally
cp .env.production .env.local

# Test build
npm run build

# Test production server
npm start
```

### Vercel Testing
1. **Push changes to GitHub**
2. **Check Vercel build logs**
3. **Test deployed application**
4. **Verify all features work**

## 🔍 Debugging Environment Issues

### Common Problems

1. **NEXTAUTH_SECRET missing**
   - Error: `Invalid NEXTAUTH_SECRET`
   - Fix: Add proper secret to Vercel env

2. **NEXTAUTH_URL incorrect**
   - Error: `Invalid callback URL`
   - Fix: Update to correct Vercel URL

3. **Database connection failed**
   - Error: `Database connection failed`
   - Fix: Check DATABASE_URL format

### Debug Commands
```bash
# Check current environment
vercel env ls

# View specific variable
vercel env pull .env.local

# Test build locally
npm run build
```

## 📱 Environment Variables Checklist

### Pre-Deployment Checklist
- [ ] NEXTAUTH_SECRET generated and added
- [ ] NEXTAUTH_URL set correctly
- [ ] NODE_ENV set to production
- [ ] DATABASE_URL configured
- [ ] WHATSAPP_NUMBER verified
- [ ] All secrets are strong and unique
- [ ] No secrets committed to Git
- [ ] Environment variables tested locally

### Post-Deployment Checklist
- [ ] Website loads without errors
- [ ] All environment variables working
- [ ] Authentication functions properly
- [ ] Database operations work
- [ ] WhatsApp integration functional
- [ ] No console errors related to env vars

---

**🔐 Keep your environment variables secure and your deployment will be smooth!**