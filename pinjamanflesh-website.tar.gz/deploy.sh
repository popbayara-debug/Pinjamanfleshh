#!/bin/bash

# PinjamanFlesh Deployment Script
# Usage: ./deploy.sh [production|development]

set -e

ENVIRONMENT=${1:-production}
echo "🚀 Starting PinjamanFlesh deployment for $ENVIRONMENT environment..."

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to print colored output
print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    print_error "Node.js is not installed. Please install Node.js 18+ first."
    exit 1
fi

# Check Node.js version
NODE_VERSION=$(node -v | cut -d'v' -f2)
REQUIRED_VERSION="18.0.0"

if [ "$(printf '%s\n' "$REQUIRED_VERSION" "$NODE_VERSION" | sort -V | head -n1)" != "$REQUIRED_VERSION" ]; then
    print_error "Node.js version $NODE_VERSION is too old. Please upgrade to 18+"
    exit 1
fi

print_success "Node.js version $NODE_VERSION ✓"

# Install dependencies
print_status "Installing dependencies..."
npm ci

# Generate Prisma client
print_status "Generating Prisma client..."
npx prisma generate

# Environment setup
if [ "$ENVIRONMENT" = "production" ]; then
    print_status "Setting up production environment..."
    
    # Check if .env.production exists
    if [ ! -f ".env.production" ]; then
        print_warning ".env.production not found. Creating from template..."
        cp .env.production.example .env.production 2>/dev/null || {
            print_error "Please create .env.production file with your production variables"
            exit 1
        }
    fi
    
    # Build application
    print_status "Building production application..."
    npm run build
    
    print_success "Production build completed ✓"
    
    # Start production server
    print_status "Starting production server..."
    if command -v pm2 &> /dev/null; then
        print_status "Using PM2 for process management..."
        pm2 restart pinjamanflesh 2>/dev/null || pm2 start npm --name "pinjamanflesh" -- start
        pm2 save
        print_success "Application started with PM2 ✓"
    else
        print_warning "PM2 not found. Starting with npm..."
        npm start
    fi
    
elif [ "$ENVIRONMENT" = "development" ]; then
    print_status "Setting up development environment..."
    
    # Push database schema
    print_status "Setting up database..."
    npx prisma db push
    
    # Start development server
    print_status "Starting development server..."
    npm run dev
    
else
    print_error "Invalid environment. Use 'production' or 'development'"
    exit 1
fi

print_success "🎉 PinjamanFlesh deployment completed successfully!"
print_status "Website is now running at http://localhost:3000"

# Health check
sleep 5
if curl -f http://localhost:3000 &> /dev/null; then
    print_success "Health check passed ✓"
else
    print_warning "Health check failed. Please check the logs."
fi