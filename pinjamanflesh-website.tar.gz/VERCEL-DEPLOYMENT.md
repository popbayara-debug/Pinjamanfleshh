# GitHub & Vercel Deployment Guide

## 📋 Step-by-Step Instructions

### 1. Setup GitHub Repository

```bash
# Initialize Git (if not already done)
git init

# Add your GitHub repository
git remote add origin https://github.com/YOUR_USERNAME/pinjamanflesh.git

# Add all files and commit
git add .
git commit -m "🚀 Initial commit: PinjamanFlesh Portfolio Website"

# Push to GitHub
git push -u origin main
```

### 2. Import to Vercel

1. **Go to [Vercel.com](https://vercel.com)**
2. **Login dengan GitHub account**
3. **Click "New Project"**
4. **Select "Import Git Repository"**
5. **Pilih repository `pinjamanflesh`**
6. **Click "Import"**

### 3. Vercel Configuration

Vercel akan otomatis mendeteksi Next.js project:

- **Framework Preset**: Next.js
- **Root Directory**: ./
- **Build Command**: `npm run build`
- **Output Directory**: `.next`
- **Install Command**: `npm install`

### 4. Environment Variables

Di Vercel dashboard, tambahkan environment variables:

```env
NODE_ENV=production
NEXTAUTH_URL=https://your-domain.vercel.app
NEXTAUTH_SECRET=your-super-secret-key-here
DATABASE_URL=file:./db/production.db
WHATSAPP_NUMBER=6285892803452
```

### 5. Deploy

- **Click "Deploy"**
- **Tunggu proses build (±2-3 menit)**
- **Website akan live di `your-project-name.vercel.app`**

## 🔧 Custom Domain Setup

### 1. Di Vercel Dashboard

1. **Go to Project Settings**
2. **Click "Domains"**
3. **Add custom domain**: `pinjamanflesh.com`
4. **Follow DNS instructions**

### 2. DNS Configuration

Di domain registrar Anda, tambahkan:

```
Type: CNAME
Name: @ (or pinjamanflesh)
Value: cname.vercel-dns.com
TTL: 300
```

### 3. SSL Certificate

Vercel akan otomatis setup SSL certificate untuk custom domain.

## 📊 Post-Deployment Testing

### Checklist Testing

- [ ] Homepage loads correctly
- [ ] All navigation links work
- [ ] Mobile responsive test
- [ ] Dark mode toggle works
- [ ] AI recommendation engine functions
- [ ] Calculator works properly
- [ ] WhatsApp integration functional
- [ ] Contact form submits
- [ ] All animations smooth
- [ ] No console errors
- [ ] Lighthouse score > 90

### Performance Testing

```bash
# Test with Lighthouse CLI
npm install -g lighthouse
lighthouse https://your-domain.vercel.app --view

# Test with PageSpeed Insights
# Visit: https://pagespeed.web.dev/
```

## 📈 Monitoring Setup

### 1. Vercel Analytics

1. **Go to Vercel Analytics tab**
2. **Enable Speed Insights**
3. **Enable Web Vitals**

### 2. Google Analytics

Tambahkan ke `src/app/layout.tsx`:

```tsx
<script
  async
  src="https://www.googletagmanager.com/gtag/js?id=GA_MEASUREMENT_ID"
/>
<script
  dangerouslySetInnerHTML={{
    __html: `
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());
      gtag('config', 'GA_MEASUREMENT_ID');
    `,
  }}
/>
```

### 3. Error Monitoring

Setup Sentry atau Vercel Error Logging:

```bash
npm install @sentry/nextjs
```

## 🔄 CI/CD Setup

### Automatic Deployments

Vercel otomatis mendeploy saat:
- **Push ke main branch** → Production
- **Push ke other branches** → Preview deployments

### Pull Request Preview

Setiap PR akan otomatis dapat preview URL untuk testing.

## 🚨 Troubleshooting

### Common Issues

1. **Build Failed**
   - Check environment variables
   - Verify Node.js version
   - Check for missing dependencies

2. **Database Error**
   - Ensure Prisma client generated
   - Check DATABASE_URL format

3. **Domain Not Working**
   - Wait 24-48 hours for DNS propagation
   - Verify CNAME record
   - Check SSL certificate

### Debug Commands

```bash
# Local build test
npm run build

# Check environment
vercel env ls

# View deployment logs
vercel logs
```

## 📞 Support Resources

- **Vercel Documentation**: https://vercel.com/docs
- **Next.js Deployment**: https://nextjs.org/docs/deployment
- **Vercel Status**: https://www.vercel-status.com/

---

**🎉 Selamat! Website PinjamanFlesh Anda siap go live!**