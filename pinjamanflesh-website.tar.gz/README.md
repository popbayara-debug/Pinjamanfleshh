# 🌟 PinjamanFlesh - Professional Loan Portfolio Website

Website portfolio PinjamanFlesh yang modern dan profesional dengan fitur-fitur canggih untuk solusi pinjaman online terpercaya.

## ✨ Fitur Unggulan

### 🤖 AI-Powered Features
- **AI Recommendation Engine** - Sistem rekomendasi pinjaman pintar berdasarkan profil pengguna
- **Smart Analytics Dashboard** - Dashboard interaktif dengan chart dan statistik real-time
- **Intelligent Form Validation** - Validasi form yang cerdas dan user-friendly

### 🎨 Modern UI/UX Design
- **Responsive Design** - Optimal di desktop, tablet, dan mobile
- **Dark Mode Support** - Tema gelap/terang dengan smooth transition
- **Micro-interactions** - Animasi halus dengan Framer Motion
- **Professional Components** - Menggunakan shadcn/ui components

### 💼 Advanced Features
- **Product Comparison Tool** - Tool perbandingan produk pinjaman interaktif
- **Advanced Calculator** - Kalkulator pinjaman dengan amortization schedule
- **Gamification System** - Sistem reward dan achievement untuk engagement
- **Customer Support Chat** - Live chat widget untuk customer service
- **WhatsApp Integration** - Direct WhatsApp connection +6285892803452

### 📊 Analytics & Monitoring
- **Real-time Statistics** - Counter animasi untuk metrics
- **Progress Tracking** - Progress bars dan loading states
- **Toast Notifications** - Notifikasi yang elegan dan informatif
- **Search Functionality** - Pencarian produk yang cepat

## 🛠️ Tech Stack

- **Framework**: Next.js 15 with App Router
- **Language**: TypeScript 5
- **Styling**: Tailwind CSS 4 + shadcn/ui
- **Database**: Prisma ORM dengan SQLite
- **Animations**: Framer Motion
- **Charts**: Recharts
- **State Management**: Zustand + TanStack Query
- **Authentication**: NextAuth.js v4
- **Form Handling**: React Hook Form + Zod
- **Icons**: Lucide React

## 🚀 Quick Start

### Prerequisites
- Node.js 18+
- npm atau yarn

### Installation

```bash
# Clone repository
git clone <your-repo-url>
cd pinjamanflesh

# Install dependencies
npm install

# Setup database
npx prisma generate
npx prisma db push

# Start development server
npm run dev
```

Website akan accessible di `http://localhost:3000`

## 📱 Available Pages

- **Home** (`/`) - Landing page dengan semua fitur
- **Portfolio** (`/portfolio`) - Portfolio showcase
- **Download** (`/download`) - Download resources
- **Auth** (`/auth`) - Authentication page

## 🔧 Configuration

### Environment Variables

```env
NODE_ENV=development
NEXTAUTH_URL=http://localhost:3000
NEXTAUTH_SECRET=your-secret-key
DATABASE_URL=file:./dev.db
WHATSAPP_NUMBER=6285892803452
```

### Database Setup

```bash
# Generate Prisma client
npx prisma generate

# Push schema to database
npx prisma db push

# (Optional) View database
npx prisma studio
```

## 📦 Build & Deployment

```bash
# Build for production
npm run build

# Start production server
npm start

# Docker deployment
docker-compose up -d
```

## 🎯 Loan Products

### Pinjaman Kilat
- Amount: 1Jt - 50Jt IDR
- Term: 1-12 bulan
- Rate: 1.8%/bln
- Features: Proses cepat, Tanpa jaminan, Cair 24 jam

### Pinjaman Modal
- Amount: 10Jt - 500Jt IDR
- Term: 6-36 bulan
- Rate: 1.5%/bln
- Features: Bunga kompetitif, Jangka waktu fleksibel, Untuk bisnis

### Pinjaman Pendidikan
- Amount: 5Jt - 100Jt IDR
- Term: 12-48 bulan
- Rate: 1.2%/bln
- Features: Bunga khusus, Grace period, Untuk pendidikan

## 🔐 Security Features

- Input validation dengan Zod schemas
- XSS protection
- CSRF protection
- Secure headers
- Rate limiting ready
- Environment variable protection

## 📈 Performance

- **Bundle Size**: 329KB (First Load JS)
- **Lighthouse Score**: 95+ (Performance, Accessibility, Best Practices)
- **SEO Optimized**: Meta tags, structured data, sitemap ready
- **Core Web Vitals**: Optimized untuk user experience

## 🎨 Customization

### Brand Colors
- Primary: Emerald gradient (emerald-500 to teal-600)
- Secondary: Purple accents
- Neutral: Slate grays

### Component Customization
Semua components menggunakan shadcn/ui yang mudah dikustomisasi:
- Edit di `src/components/ui/`
- Tailwind configuration di `tailwind.config.ts`

## 🤝 Contributing

1. Fork repository
2. Create feature branch (`git checkout -b feature/amazing-feature`)
3. Commit changes (`git commit -m 'Add amazing feature'`)
4. Push to branch (`git push origin feature/amazing-feature`)
5. Open Pull Request

## 📄 License

This project is proprietary software for PinjamanFlesh.

## 📞 Contact

- **WhatsApp**: +6285892803452
- **Email**: info@pinjamanflesh.com
- **Website**: https://pinjamanflesh.com

---

**🚀 PinjamanFlesh - Solusi Pinjaman Online Terpercaya dan Modern**