#!/bin/bash

# GitHub Repository Setup Script for PinjamanFlesh
# This script helps you push to GitHub for Vercel deployment

echo "🚀 Setting up PinjamanFlesh GitHub Repository..."

# Colors
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
NC='\033[0m'

print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

# Check if git is initialized
if [ ! -d ".git" ]; then
    print_status "Initializing Git repository..."
    git init
fi

# Add all files
print_status "Adding files to Git..."
git add .

# Initial commit
print_status "Creating initial commit..."
git commit -m "🚀 Initial commit: PinjamanFlesh - Professional Loan Portfolio Website

✨ Features:
- AI-powered loan recommendation engine
- Interactive analytics dashboard with charts
- Advanced product comparison tools
- Customer testimonials with video reviews
- Gamification system with rewards and achievements
- Advanced calculator with amortization schedule
- Dark mode toggle and responsive design
- WhatsApp integration (+6285892803452)
- Customer support chat widget
- Toast notifications and loading states
- Search functionality
- Animated counters and progress indicators

🛠️ Tech Stack:
- Next.js 15 with App Router
- TypeScript 5
- Tailwind CSS 4 + shadcn/ui
- Prisma ORM with SQLite
- Framer Motion animations
- Recharts for data visualization
- Zustand for state management

📦 Ready for Vercel deployment!"

# Add remote (you need to replace with your repository URL)
print_warning "Please add your GitHub repository URL:"
echo "git remote add origin https://github.com/YOUR_USERNAME/pinjamanflesh.git"
echo ""
print_status "After adding remote, run:"
echo "git push -u origin main"
echo ""
print_success "Repository is ready for GitHub push!"

# Instructions for Vercel
echo ""
echo "🎯 Next Steps for Vercel Deployment:"
echo "1. Push to GitHub using the commands above"
echo "2. Go to https://vercel.com"
echo "3. Click 'Import Project' and connect your GitHub"
echo "4. Select the pinjamanflesh repository"
echo "5. Configure environment variables (see .env.production)"
echo "6. Deploy! 🚀"