# 🚀 PinjamanFlesh Deployment Guide

Website PinjamanFlesh siap untuk deployment! Berikut adalah panduan lengkap untuk mempublish website Anda.

## 📋 Prasyarat

- Node.js 18+ 
- Docker & Docker Compose (opsional)
- Domain name (opsional)
- Server/VPS atau platform deployment

## 🐳 Docker Deployment (Recommended)

### 1. Build & Run dengan Docker Compose

```bash
# Clone repository
git clone <your-repo-url>
cd pinjamanflesh

# Setup environment variables
cp .env.production .env
# Edit .env dengan konfigurasi Anda

# Build dan jalankan
docker-compose up -d
```

### 2. Build Manual dengan Docker

```bash
# Build image
docker build -t pinjamanflesh .

# Jalankan container
docker run -p 3000:3000 -e NODE_ENV=production pinjamanflesh
```

## 🖥️ Server Deployment Manual

### 1. Build Production

```bash
# Install dependencies
npm install

# Generate Prisma client
npx prisma generate

# Build production
npm run build

# Start production server
npm start
```

### 2. Setup dengan PM2 (Recommended untuk VPS)

```bash
# Install PM2
npm install -g pm2

# Start dengan PM2
pm2 start npm --name "pinjamanflesh" -- start

# Save PM2 config
pm2 save
pm2 startup
```

## ☁️ Cloud Platform Deployment

### Vercel (Recommended)

1. Push ke GitHub repository
2. Connect GitHub ke Vercel
3. Setup environment variables di Vercel dashboard
4. Deploy otomatis

### Netlify

1. Build command: `npm run build`
2. Publish directory: `.next`
3. Environment variables di Netlify dashboard

### Railway/Render

1. Connect GitHub repository
2. Setup build command: `npm run build`
3. Start command: `npm start`
4. Environment variables di dashboard

## 🔧 Environment Variables

Edit file `.env.production`:

```env
NODE_ENV=production
NEXTAUTH_URL=https://yourdomain.com
NEXTAUTH_SECRET=your-super-secret-key
DATABASE_URL=file:./db/production.db
WHATSAPP_NUMBER=6285892803452
```

## 🌐 Domain Setup

### Dengan Nginx Reverse Proxy

```nginx
server {
    listen 80;
    server_name yourdomain.com;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
}
```

### SSL Certificate (Let's Encrypt)

```bash
# Install certbot
sudo apt install certbot python3-certbot-nginx

# Generate SSL certificate
sudo certbot --nginx -d yourdomain.com
```

## 📊 Monitoring & Maintenance

### Health Check

```bash
# Check if service is running
curl http://localhost:3000/api/health

# Check logs
docker-compose logs -f
# atau
pm2 logs pinjamanflesh
```

### Database Backup

```bash
# Backup database
cp db/production.db backup/production-$(date +%Y%m%d).db

# Automate dengan cron
0 2 * * * cp /path/to/db/production.db /path/to/backup/production-$(date +\%Y\%m\%d).db
```

## 🔒 Security Checklist

- [ ] Ganti default NEXTAUTH_SECRET
- [ ] Setup firewall (port 80, 443, 22)
- [ ] Enable HTTPS dengan SSL
- [ ] Regular database backups
- [ ] Monitor error logs
- [ ] Update dependencies regularly

## 📈 Performance Optimization

- [ ] Enable CDN untuk static assets
- [ ] Setup caching headers
- [ ] Compress images
- [ ] Monitor Core Web Vitals
- [ ] Setup analytics (Google Analytics)

## 🆘 Troubleshooting

### Common Issues

1. **Build Error**: 
   - Cek Node.js version (minimal 18)
   - Hapus node_modules dan install ulang

2. **Database Error**:
   - Pastikan Prisma sudah di-generate
   - Cek DATABASE_URL path

3. **Port Already in Use**:
   ```bash
   # Kill process on port 3000
   sudo lsof -ti:3000 | xargs kill -9
   ```

## 🎉 Deployment Success!

Setelah deployment berhasil:

1. Website akan accessible di port 3000 atau domain Anda
2. Test semua fitur (form, WhatsApp, calculator)
3. Monitor performance di browser dev tools
4. Setup monitoring dan alerts

## 📞 Support

Jika ada masalah deployment:
- Cek error logs: `docker-compose logs` atau `pm2 logs`
- Verify environment variables
- Pastikan semua dependencies terinstall

---

**🎯 Selamat! Website PinjamanFlesh Anda sudah live dan siap menerima pengajuan pinjaman!**